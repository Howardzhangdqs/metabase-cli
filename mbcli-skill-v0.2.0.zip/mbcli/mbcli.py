#!/usr/bin/env python3
"""mbcli 单文件脚本 —— 由 scripts/build-single.py 自动生成，请勿手改。

源码 src/mbcli/ 为权威实现（测试与开发都在源码上进行）。

目标机要求：Python >= 3.10，且已安装 typer>=0.12 与 httpx>=0.27
（rich 由 typer 携带，仅 --format table 需要；依赖不随本文件打包，
直接使用目标机自带的库）。

用法：python3 mbcli.py …（与安装版 mbcli 命令完全等价）。

重新生成：uv run python scripts/build-single.py（修改 src/ 后必须重新生成；需在装有 typer/httpx 的环境运行）。

生成时间：2026-10-31T06:42:40Z（SOURCE_DATE_EPOCH 可覆盖，便于可复现构建）
mbcli 版本：0.1.0
"""
from __future__ import annotations

import types
import json
import sys
import os
import tempfile
import httpx
import time
import re
import csv
import io
import typer
import contextlib
import shlex

from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Annotated, Any
from collections.abc import Callable, Iterable, Mapping, Sequence
from pathlib import Path
from enum import Enum
from rich.console import Console
from rich.table import Table as RichTable
from collections import Counter

__version__ = "0.1.0"

_ns = types.SimpleNamespace


#---------------------------------------------------------------------------
# mbcli.errors  (merged: src/mbcli/errors.py)
#---------------------------------------------------------------------------
EXIT_OK = 0
EXIT_ERROR = 1
EXIT_USAGE = 2

# DESIGN §3.3 error normalization table: code -> process exit code.
ERROR_EXIT_CODES: dict[str, int] = {
    "auth_failed": EXIT_ERROR,
    "permission_denied": EXIT_ERROR,
    "not_found": EXIT_ERROR,
    "bad_query": EXIT_ERROR,
    "invalid_request": EXIT_ERROR,
    "rate_limited": EXIT_ERROR,
    "server_error": EXIT_ERROR,
    "network_error": EXIT_ERROR,
    "timeout": EXIT_ERROR,
    "config_missing": EXIT_ERROR,
    "unhealthy": EXIT_ERROR,
    "ambiguous_ref": EXIT_ERROR,
    "invalid_response": EXIT_ERROR,
    "not_implemented": EXIT_ERROR,
    "invalid_args": EXIT_USAGE,
    "write_blocked": EXIT_USAGE,
}


@dataclass
class MbcliError(Exception):
    """Every failure mode of mbcli, normalized to a code + message + detail.

    The stderr rendering is a single line of JSON:
    {"error":{"code":"...","message":"...","detail":{...}}}
    """

    code: str
    message: str
    detail: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        super().__init__(self.message)

    @property
    def exit_code(self) -> int:
        return ERROR_EXIT_CODES.get(self.code, EXIT_ERROR)

    def to_stderr_json(self) -> str:
        payload = {
            "error": {
                "code": self.code,
                "message": " ".join(str(self.message).split()),
                "detail": self.detail or {},
            }
        }
        return json.dumps(payload, ensure_ascii=False)

    def emit(self, stream: Any | None = None) -> None:
        stream = sys.stderr if stream is None else stream
        stream.write(self.to_stderr_json() + "\n")

errors = _ns(
    ERROR_EXIT_CODES=ERROR_EXIT_CODES,
    EXIT_ERROR=EXIT_ERROR,
    EXIT_OK=EXIT_OK,
    EXIT_USAGE=EXIT_USAGE,
    MbcliError=MbcliError,
)


#---------------------------------------------------------------------------
# mbcli.config  (merged: src/mbcli/config.py)
#---------------------------------------------------------------------------
try:  # Python >= 3.11
    import tomllib
except ImportError:  # pragma: no cover - Python 3.10 fallback
    tomllib = None  # type: ignore[assignment]

DEFAULT_TIMEOUT = 60

# --read-only hint raised by commands when --db is omitted and no default exists
# (DESIGN §3.1 `default_db`; the message must hint all three fixes)
NO_DB_MESSAGE = (
    "no database selected: pass --db, run `mbcli connect --default-db`, or set MB_DEFAULT_DB"
)

# .env whitelist (DESIGN §2: no python-dotenv, ~20 line built-in parser).
ENV_KEY_MAP: dict[str, str] = {
    "MB_URL": "url",
    "MB_USERNAME": "username",
    "MB_PASSWORD": "password",
    "MB_API_KEY": "api_key",
}
DOTENV_WHITELIST = frozenset(ENV_KEY_MAP)

TOML_SECTION = "metabase"
TOML_KEYS = frozenset(
    {"url", "api_key", "username", "password", "timeout", "session_cache", "default_db"}
)


def default_session_cache() -> str:
    return str(Path.home() / ".cache" / "mbcli" / "session.json")


def default_toml_path() -> Path:
    return Path.home() / ".config" / "mbcli" / "config.toml"


@dataclass
class Config:
    """Resolved configuration. `url` is always slash-stripped and non-empty
    (except for the internal require_url=False path used by `mbcli connect`,
    which resolves the remaining keys before prompting for the URL)."""

    url: str
    api_key: str | None = None
    username: str | None = None
    password: str | None = None
    timeout: int = DEFAULT_TIMEOUT
    session_cache: str = field(default_factory=default_session_cache)
    # --db fallback chain (DESIGN §3.1): MB_DEFAULT_DB env > config.toml default_db
    default_db: str | None = None
    # where `connect` persists the [metabase] section (MB_CONFIG_FILE redirects)
    config_file: str = field(default_factory=lambda: str(default_toml_path()))

    def httpx_timeout(self) -> httpx.Timeout:
        """DESIGN §3.1: N is a per-request read timeout, not a total duration."""
        return httpx.Timeout(
            connect=5.0,
            read=float(self.timeout),
            write=float(self.timeout),
            pool=5.0,
        )

    def require_credentials(self) -> None:
        """Lazy credential check: no api key and no full username/password pair."""
        if self.api_key:
            return
        missing = [
            name
            for name, value in (("MB_USERNAME", self.username), ("MB_PASSWORD", self.password))
            if not value
        ]
        if missing:
            raise MbcliError(
                "config_missing",
                "missing credentials: set MB_API_KEY or " + " and ".join(missing),
            )


def effective_db_ref(explicit: str | None, config: Config) -> str:
    """Resolve the database reference for a command: explicit `--db` wins, then
    the `default_db` fallback (MB_DEFAULT_DB env > config.toml, already merged
    into `config`). All three missing -> invalid_args (exit 2) with a message
    hinting every fix (DESIGN §3.1, ADR #18)."""
    if explicit:
        return explicit
    if config.default_db:
        return str(config.default_db)
    raise MbcliError("invalid_args", NO_DB_MESSAGE)


def _config___clean(value: str | None) -> str | None:
    """Treat empty / whitespace-only strings as unset."""
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def parse_dotenv(path: str | Path) -> dict[str, str]:
    """Parse a .env file: whitelist keys only, '#' comments, quote stripping."""
    file = Path(path).expanduser()
    if not file.is_file():
        return {}
    values: dict[str, str] = {}
    for line in file.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, raw = stripped.partition("=")
        key = key.strip()
        if key not in DOTENV_WHITELIST:
            continue
        value = raw.strip()
        if value[:1] in ("'", '"'):
            # quoted: keep everything (incl. '#') up to the matching close quote
            end = value.find(value[0], 1)
            if end != -1:
                value = value[1:end]
        else:
            # unquoted: strip a trailing comment
            comment_at = value.find(" #")
            if comment_at != -1:
                value = value[:comment_at].rstrip()
        if value:
            values[key] = value
    return values


def parse_toml(path: str | Path) -> dict[str, Any]:
    """Parse ~/.config/mbcli/config.toml; only the [metabase] section is honored."""
    file = Path(path).expanduser()
    if tomllib is None or not file.is_file():
        return {}
    try:
        data = tomllib.loads(file.read_text(encoding="utf-8"))
    except (tomllib.TOMLDecodeError, OSError):
        return {}
    section = data.get(TOML_SECTION)
    if not isinstance(section, dict):
        return {}
    return {key: value for key, value in section.items() if key in TOML_KEYS}


def load_config(
    cli: Mapping[str, Any] | None = None,
    *,
    env: Mapping[str, str] | None = None,
    dotenv_path: str | Path | None = None,
    toml_path: str | Path | None = None,
    require_url: bool = True,
) -> Config:
    """Resolve configuration from all sources. Raises config_missing without a
    URL (unless require_url=False, the lenient path used by `mbcli connect`,
    which prompts for the URL itself)."""
    cli_over: dict[str, Any] = dict(cli or {})
    env_map: Mapping[str, str] = os.environ if env is None else env
    dotenv = parse_dotenv(Path(".env") if dotenv_path is None else dotenv_path)
    # where to read the [metabase] section from: explicit test injection >
    # MB_CONFIG_FILE env > default path (DESIGN §3.1 config_file row)
    config_file = (
        str(toml_path)
        if toml_path is not None
        else (cli_over.get("config_file") or _config___clean(env_map.get("MB_CONFIG_FILE")))
    )
    if not config_file:
        config_file = str(default_toml_path())
    toml_cfg = parse_toml(config_file)

    def pick(key: str, env_key: str, default: Any) -> Any:
        if cli_over.get(key) is not None:
            return cli_over[key]
        for source in (env_map, dotenv):
            value = _config___clean(source.get(env_key))
            if value is not None:
                return value
        if toml_cfg.get(key) is not None:
            return toml_cfg[key]
        return default

    url = _config___clean(str(pick("url", "MB_URL", "") or ""))
    if not url and require_url:
        raise MbcliError(
            "config_missing",
            "MB_URL is not set: use --url, the MB_URL environment variable, .env,"
            " or run `mbcli connect` once",
        )

    timeout_raw = pick("timeout", "MB_TIMEOUT", DEFAULT_TIMEOUT)
    try:
        timeout = int(timeout_raw)
    except (TypeError, ValueError) as exc:
        raise MbcliError(
            "config_missing", f"invalid timeout value {timeout_raw!r}: must be an integer"
        ) from exc

    default_db_raw = pick("default_db", "MB_DEFAULT_DB", None)
    default_db = _config___clean(str(default_db_raw)) if default_db_raw is not None else None

    return Config(
        url=(url or "").rstrip("/"),
        api_key=_config___clean(str(pick("api_key", "MB_API_KEY", "") or "")),
        username=_config___clean(str(pick("username", "MB_USERNAME", "") or "")),
        password=_config___clean(str(pick("password", "MB_PASSWORD", "") or "")),
        timeout=timeout,
        session_cache=str(pick("session_cache", "MB_SESSION_CACHE", default_session_cache())),
        default_db=default_db,
        config_file=str(config_file),
    )


# -- [metabase] section persistence (connect/disconnect, ADR #18) ------------------
#
# Python 3.10 has no TOML writer in the stdlib (tomllib is read-only), so the
# flat string-only section is hand-written with proper basic-string quoting;
# reading goes through the existing tomllib-based parse_toml.


def _config___toml_quote(value: str) -> str:
    """Escape as a TOML basic string: backslash, double quote, control chars."""
    escaped = (
        value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")
    )
    escaped = "".join(char if char >= " " else f"\\u{ord(char):04X}" for char in escaped)
    return f'"{escaped}"'


def _config___atomic_write(path: Path, text: str) -> None:
    """Tempfile in the same directory -> chmod 0600 -> os.replace; dir 0700
    (same discipline as the session cache, DESIGN §3.2)."""
    directory = path.parent
    directory_existed = directory.is_dir()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not directory_existed:
        try:
            os.chmod(directory, 0o700)
        except OSError:
            pass
    fd, tmp_name = tempfile.mkstemp(dir=directory, prefix=".config-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.chmod(tmp_name, 0o600)
        os.replace(tmp_name, path)
    except OSError:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def save_metabase_section(config_file: str | Path, values: Mapping[str, Any]) -> None:
    """Atomically persist exactly the given [metabase] keys (order preserved,
    None values skipped). Replaces any previous [metabase] section."""
    path = Path(config_file).expanduser()
    lines = ["[metabase]"]
    lines += [
        f"{key} = {_config___toml_quote(str(value))}" for key, value in values.items() if value is not None
    ]
    _config___atomic_write(path, "\n".join(lines) + "\n")


def remove_metabase_section(config_file: str | Path) -> bool:
    """Drop the [metabase] section; delete the file when nothing meaningful
    (non-comment, non-blank) remains. Returns True if a section was present."""
    path = Path(config_file).expanduser()
    if not path.is_file():
        return False
    kept: list[str] = []
    in_metabase = False
    saw_metabase = False
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            in_metabase = stripped == f"[{TOML_SECTION}]"
            saw_metabase = saw_metabase or in_metabase
            if not in_metabase:
                kept.append(line)
            continue
        if not in_metabase:
            kept.append(line)
    if not saw_metabase:
        return False
    meaningful = [line for line in kept if line.strip() and not line.strip().startswith("#")]
    if not meaningful:
        path.unlink()
    else:
        _config___atomic_write(path, "\n".join(kept).rstrip("\n") + "\n")
    return True

config = _ns(
    Config=Config,
    DEFAULT_TIMEOUT=DEFAULT_TIMEOUT,
    DOTENV_WHITELIST=DOTENV_WHITELIST,
    ENV_KEY_MAP=ENV_KEY_MAP,
    NO_DB_MESSAGE=NO_DB_MESSAGE,
    TOML_KEYS=TOML_KEYS,
    TOML_SECTION=TOML_SECTION,
    _atomic_write=_config___atomic_write,
    _clean=_config___clean,
    _toml_quote=_config___toml_quote,
    default_session_cache=default_session_cache,
    default_toml_path=default_toml_path,
    effective_db_ref=effective_db_ref,
    load_config=load_config,
    parse_dotenv=parse_dotenv,
    parse_toml=parse_toml,
    remove_metabase_section=remove_metabase_section,
    save_metabase_section=save_metabase_section,
)


#---------------------------------------------------------------------------
# mbcli.auth  (merged: src/mbcli/auth.py)
#---------------------------------------------------------------------------
SESSION_TTL_SECONDS = 14 * 24 * 3600
SESSION_PATH = "/api/session"

SENSITIVE_KEYS = frozenset(
    {"password", "api_key", "authorization", "x-api-key", "x-metabase-session"}
)


def redact_secrets(value: Any) -> Any:
    """Recursively replace credential values with '***' for verbose logging."""
    if isinstance(value, dict):
        return {
            key: ("***" if str(key).lower() in SENSITIVE_KEYS and item else redact_secrets(item))
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [redact_secrets(item) for item in value]
    return value


class AuthManager:
    def __init__(self, config: Config, log: Callable[[str], None] | None = None) -> None:
        self.config = config
        self._log = log
        self._session_id: str | None = None

    @property
    def uses_api_key(self) -> bool:
        return bool(self.config.api_key)

    def auth_headers(self) -> dict[str, str]:
        """Headers authenticating the next request (triggers login if needed)."""
        if self.config.api_key:
            return {"X-API-Key": self.config.api_key}
        return {"X-Metabase-Session": self._ensure_session()}

    def invalidate(self) -> None:
        """Forget the current session (memory + cache file)."""
        self._session_id = None
        try:
            Path(self.config.session_cache).expanduser().unlink(missing_ok=True)
        except OSError:
            pass

    # -- session cache ----------------------------------------------------

    def _read_cache(self) -> dict[str, Any] | None:
        try:
            data = json.loads(Path(self.config.session_cache).expanduser().read_text("utf-8"))
        except (OSError, ValueError):
            return None  # missing or corrupt: silently ignored
        if not isinstance(data, dict):
            return None
        session_id = data.get("session_id")
        obtained_at = data.get("obtained_at")
        if not isinstance(session_id, str) or not session_id:
            return None
        if not isinstance(obtained_at, int | float):
            return None
        if time.time() - obtained_at > SESSION_TTL_SECONDS:
            return None  # expired
        return {"session_id": session_id, "obtained_at": obtained_at}

    def _write_cache(self, session_id: str) -> None:
        path = Path(self.config.session_cache).expanduser()
        directory = path.parent
        directory_existed = directory.is_dir()
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not directory_existed:
            try:
                os.chmod(directory, 0o700)
            except OSError:
                pass
        fd, tmp_name = tempfile.mkstemp(dir=directory, prefix=".session-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(json.dumps({"session_id": session_id, "obtained_at": time.time()}))
            os.chmod(tmp_name, 0o600)
            os.replace(tmp_name, path)
        except OSError:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass

    def _ensure_session(self) -> str:
        if self._session_id:
            return self._session_id
        cached = self._read_cache()
        if cached is not None:
            self._session_id = cached["session_id"]
            return self._session_id
        return self._login()

    # -- login ------------------------------------------------------------

    def _login(self) -> str:
        """POST /api/session. Any response-level failure -> auth_failed (ADR #15)."""
        self.config.require_credentials()
        payload = {"username": self.config.username, "password": self.config.password}
        if self._log:
            self._log(
                f"request: POST {SESSION_PATH}"
                f" body={json.dumps(redact_secrets(payload), ensure_ascii=False)}"
            )
        try:
            response = httpx.post(
                f"{self.config.url}{SESSION_PATH}",
                json=payload,
                timeout=self.config.httpx_timeout(),
                follow_redirects=False,
            )
        except httpx.TimeoutException as exc:
            raise MbcliError("timeout", f"login request timed out: {exc}") from exc
        except httpx.TransportError as exc:
            raise MbcliError("network_error", f"login connection failed: {exc}") from exc
        if self._log:
            self._log(f"response: {response.status_code} {SESSION_PATH}")
        if response.status_code != 200:
            raise MbcliError(
                "auth_failed",
                f"login failed ({response.status_code}): {' '.join(response.text.split())[:200]}",
                detail={"http_status": response.status_code},
            )
        try:
            session_id = response.json().get("id")
        except ValueError as exc:
            raise MbcliError("auth_failed", "login response is not valid JSON") from exc
        if not isinstance(session_id, str) or not session_id:
            raise MbcliError("auth_failed", "login response missing session id")
        self._write_cache(session_id)
        self._session_id = session_id
        return session_id

auth = _ns(
    AuthManager=AuthManager,
    SENSITIVE_KEYS=SENSITIVE_KEYS,
    SESSION_PATH=SESSION_PATH,
    SESSION_TTL_SECONDS=SESSION_TTL_SECONDS,
    redact_secrets=redact_secrets,
)


#---------------------------------------------------------------------------
# mbcli.guard  (merged: src/mbcli/guard.py)
#---------------------------------------------------------------------------
READONLY_KEYWORDS = frozenset({"SELECT", "WITH", "SHOW", "DESCRIBE", "EXPLAIN"})

_guard___LEADING_KEYWORD = re.compile(r"[\s(]*([A-Za-z_][A-Za-z_0-9]*)")


def scan_statements(sql: str) -> list[str]:
    """Strip comments (string-aware) and split on ';' outside literals/backticks."""
    statements: list[str] = []
    current: list[str] = []
    i = 0
    n = len(sql)
    quote: str | None = None  # "'", '"', or '`' while inside a literal
    while i < n:
        ch = sql[i]
        if quote is not None:
            current.append(ch)
            if ch == "\\" and quote in ("'", '"') and i + 1 < n:
                current.append(sql[i + 1])
                i += 2
                continue
            if ch == quote:
                if i + 1 < n and sql[i + 1] == quote:  # doubled-quote escape
                    current.append(sql[i + 1])
                    i += 2
                    continue
                quote = None
            i += 1
            continue
        if ch in ("'", '"', "`"):
            quote = ch
            current.append(ch)
            i += 1
            continue
        if ch == "-" and i + 1 < n and sql[i + 1] == "-":  # -- line comment
            while i < n and sql[i] != "\n":
                i += 1
            continue
        if ch == "#":  # MySQL line comment
            while i < n and sql[i] != "\n":
                i += 1
            continue
        if ch == "/" and i + 1 < n and sql[i + 1] == "*":  # block comment
            i += 2
            while i + 1 < n and not (sql[i] == "*" and sql[i + 1] == "/"):
                i += 1
            i = min(i + 2, n)
            continue
        if ch == ";":
            statements.append("".join(current))
            current = []
            i += 1
            continue
        current.append(ch)
        i += 1
    statements.append("".join(current))
    return [statement.strip() for statement in statements if statement.strip()]


def first_keyword(statement: str) -> str | None:
    match = _guard___LEADING_KEYWORD.match(statement)
    return match.group(1).upper() if match else None


def check_readonly(sql: str, allow_write: bool = False) -> list[str]:
    """Validate that every statement is read-only. Raises MbcliError otherwise.

    Returns the list of (comment-stripped) statements. With allow_write=True the
    check is bypassed entirely and an empty list is returned.
    """
    if allow_write:
        return []
    statements = scan_statements(sql)
    if not statements:
        raise MbcliError(
            "invalid_args",
            "SQL contains no statements (empty or comments only)",
        )
    for statement in statements:
        keyword = first_keyword(statement)
        if keyword is None:
            raise MbcliError(
                "write_blocked",
                "statement does not start with a SQL keyword; re-run with --allow-write"
                " to allow non-read-only statements",
                detail={"statement": statement[:120]},
            )
        if keyword not in READONLY_KEYWORDS:
            raise MbcliError(
                "write_blocked",
                f"non-read-only statement rejected (leading keyword {keyword});"
                " re-run with --allow-write to allow write operations",
                detail={"keyword": keyword, "statement": statement[:120]},
            )
    return statements

guard = _ns(
    READONLY_KEYWORDS=READONLY_KEYWORDS,
    _LEADING_KEYWORD=_guard___LEADING_KEYWORD,
    check_readonly=check_readonly,
    first_keyword=first_keyword,
    scan_statements=scan_statements,
)


#---------------------------------------------------------------------------
# mbcli.models  (merged: src/mbcli/models.py)
#---------------------------------------------------------------------------
class _models___Model:
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# -- misc / health -----------------------------------------------------------


@dataclass
class WhoamiInfo(_models___Model):
    id: int
    email: str | None
    is_superuser: bool
    group_ids: list[int] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> WhoamiInfo:
        return cls(
            id=payload.get("id"),
            email=payload.get("email"),
            is_superuser=bool(payload.get("is_superuser", False)),
            group_ids=list(payload.get("group_ids") or []),
        )


@dataclass
class HealthInfo(_models___Model):
    status: str
    version: str | None = None


# -- metadata (§5.1) -----------------------------------------------------------


@dataclass
class DatabaseInfo(_models___Model):
    id: int
    name: str
    engine: str | None
    description: str | None
    is_sample: bool
    initial_sync_status: str | None
    timezone: str | None
    # the live instance returns an object ({"flavor","version",...}); pass through as-is
    dbms_version: Any = None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> DatabaseInfo:
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            engine=payload.get("engine"),
            description=payload.get("description"),
            is_sample=bool(payload.get("is_sample", False)),
            initial_sync_status=payload.get("initial_sync_status"),
            timezone=payload.get("timezone"),
            dbms_version=payload.get("dbms_version"),
        )


@dataclass
class SchemaInfo(_models___Model):
    name: str
    table_count: int


@dataclass
class TableInfo(_models___Model):
    id: int
    schema: str | None
    name: str
    display_name: str | None
    description: str | None
    estimated_row_count: int | None  # approximate; do not rely on it
    active: bool
    field_count: int = 0

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> TableInfo:
        return cls(
            id=payload.get("id"),
            schema=payload.get("schema"),
            name=payload.get("name"),
            display_name=payload.get("display_name"),
            description=payload.get("description"),
            estimated_row_count=payload.get("estimated_row_count"),
            active=bool(payload.get("active", True)),
            field_count=len(payload.get("fields") or []),
        )


@dataclass
class FKTarget(_models___Model):
    table: str | None
    field: str | None


@dataclass
class FieldInfo(_models___Model):
    id: int
    name: str
    display_name: str | None
    base_type: str | None
    semantic_type: str | None
    database_type: str | None
    description: str | None
    is_pk: bool
    is_nullable: bool | None
    is_indexed: bool | None
    fk_target: FKTarget | None
    position: int | None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> FieldInfo:
        target = payload.get("target")
        fk_target = None
        if isinstance(target, dict):
            table = target.get("table")
            if isinstance(table, dict):
                fk_target = FKTarget(table=table.get("name"), field=target.get("name"))
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            display_name=payload.get("display_name"),
            base_type=payload.get("base_type"),
            semantic_type=payload.get("semantic_type"),
            database_type=payload.get("database_type"),
            description=payload.get("description"),
            is_pk=bool(payload.get("database_is_pk", False)),
            is_nullable=payload.get("database_is_nullable"),
            is_indexed=payload.get("database_indexed"),
            fk_target=fk_target,
            # DESIGN §5.1: position comes from the physical column order
            # (database_position), not the UI override (`position`).
            position=(
                payload["database_position"]
                if payload.get("database_position") is not None
                else payload.get("position")
            ),
        )


@dataclass
class CollectionRef(_models___Model):
    id: int | str | None
    name: str | None


@dataclass
class CollectionInfo(_models___Model):
    id: int | str
    name: str
    parent_id: int | str | None
    authority_level: int | None
    is_personal: bool

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> CollectionInfo:
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            parent_id=payload.get("parent_id"),
            authority_level=payload.get("authority_level"),
            is_personal=bool(payload.get("is_personal", False)),
        )


@dataclass
class CollectionItem(_models___Model):
    id: int | str
    model: str | None
    name: str | None
    description: str | None
    collection: CollectionRef | None
    display: str | None
    updated_at: str | None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> CollectionItem:
        collection = payload.get("collection")
        if not isinstance(collection, dict):
            collection_id = payload.get("collection_id")
            collection = {"id": collection_id} if collection_id is not None else None
        return cls(
            id=payload.get("id"),
            model=payload.get("model"),
            name=payload.get("name"),
            description=payload.get("description"),
            collection=(
                CollectionRef(id=collection["id"], name=collection.get("name"))
                if collection
                else None
            ),
            display=payload.get("display"),
            updated_at=payload.get("updated_at"),
        )


@dataclass
class CollectionListing(_models___Model):
    total: int | None
    limit: int | None
    offset: int | None
    items: list[CollectionItem] = field(default_factory=list)

    @classmethod
    def from_api(
        cls, payload: dict[str, Any], items: list[CollectionItem] | None = None
    ) -> CollectionListing:
        return cls(
            total=payload.get("total"),
            limit=payload.get("limit"),
            offset=payload.get("offset"),
            items=list(items or []),
        )


@dataclass
class SearchItem(_models___Model):
    id: int | str
    model: str | None
    name: str | None
    description: str | None
    collection: CollectionRef | None
    database_id: int | None
    updated_at: str | None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> SearchItem:
        return cls(
            id=payload.get("id"),
            model=payload.get("model"),
            name=payload.get("name"),
            description=payload.get("description"),
            collection=(
                CollectionRef(
                    id=payload["collection"]["id"], name=payload["collection"].get("name")
                )
                if isinstance(payload.get("collection"), dict)
                else None
            ),
            database_id=payload.get("database_id"),
            updated_at=payload.get("updated_at"),
        )


# -- query envelope (§5.2) ------------------------------------------------------


@dataclass
class ColumnInfo(_models___Model):
    name: str
    base_type: str | None
    database_type: str | None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> ColumnInfo:
        return cls(
            name=payload.get("name"),
            base_type=payload.get("base_type"),
            database_type=payload.get("database_type"),
        )


@dataclass
class QueryEnvelope(_models___Model):
    status: str
    row_count: int
    rows_returned: int
    truncated: bool
    columns: list[ColumnInfo] = field(default_factory=list)
    rows: list[list[Any]] = field(default_factory=list)
    running_time_ms: int | None = None
    cached: bool = False
    data_warnings: list[str] = field(default_factory=list)

    @classmethod
    def from_response(cls, payload: dict[str, Any], max_rows: int = 0) -> QueryEnvelope:
        """Client-side truncation contract (§5.2, ADR #12): the server ignores
        request-level limits, so we truncate in memory and report
        truncated/rows_returned explicitly."""
        data = payload.get("data") or {}
        columns = [
            ColumnInfo.from_api(col) for col in (data.get("cols") or []) if isinstance(col, dict)
        ]
        server_rows = data.get("rows") or []
        row_count = len(server_rows)
        if max_rows and max_rows > 0:
            truncated = row_count > max_rows
            out_rows = server_rows[:max_rows]
        else:
            truncated = False
            out_rows = server_rows
        warnings: list[str] = []
        if data.get("rows_truncated"):
            warnings.append("server truncated rows in this response (data.rows_truncated)")
        return cls(
            status=payload.get("status") or "completed",
            row_count=row_count,
            rows_returned=len(out_rows),
            truncated=truncated,
            columns=columns,
            rows=out_rows,
            running_time_ms=payload.get("running_time"),
            cached=bool(payload.get("cached", False)),
            data_warnings=warnings,
        )


# -- cards / dashboards (§5.3) ----------------------------------------------------


@dataclass
class LastEdit(_models___Model):
    user: str | None
    at: str | None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> LastEdit | None:
        if not isinstance(payload, dict):
            return None
        user = " ".join(
            part for part in (payload.get("first_name"), payload.get("last_name")) if part
        )
        return cls(
            user=user or payload.get("email") or payload.get("username"),
            at=payload.get("timestamp"),
        )


@dataclass
class CardDetail(_models___Model):
    id: int | str
    name: str | None
    description: str | None
    collection: CollectionRef | None
    display: str | None
    query_type: str | None  # "native" | "mbql"
    database_id: int | None
    sql: str | None
    mbql: dict[str, Any] | None
    parameters: list[Any] = field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None
    last_edit: LastEdit | None = None

    @staticmethod
    def _parse_legacy_query(
        legacy: dict[str, Any],
    ) -> tuple[str | None, str | None, dict[str, Any] | None]:
        query_type = legacy.get("type")
        sql = None
        mbql = None
        if query_type == "native":
            native = legacy.get("native") or {}
            sql = native.get("query") if isinstance(native, dict) else None
        elif query_type == "query":
            mbql = legacy.get("query")
            query_type = "mbql"
        else:
            return None, None, None
        return query_type, sql, mbql

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> CardDetail:
        dataset_query = payload.get("dataset_query")
        source: dict[str, Any] = dataset_query if isinstance(dataset_query, dict) else {}
        query_type: str | None = None
        sql: str | None = None
        mbql: dict[str, Any] | None = None

        if source.get("lib/type") == "mbql/query":
            # v57+ pMBQL: native SQL lives in the LAST mbql.stage/native stage
            # (probe-verified on card 7876, instance v0.66).
            stages = source.get("stages")
            native_stage = None
            if isinstance(stages, list):
                for stage in stages:
                    if isinstance(stage, dict) and stage.get("lib/type") == "mbql.stage/native":
                        native_stage = stage
            if native_stage is not None:
                query_type, sql = "native", native_stage.get("native")
            else:
                query_type, mbql = "mbql", source
        else:
            query_type, sql, mbql = cls._parse_legacy_query(source)

        if query_type is None:
            # Fallback: `legacy_query` is a JSON-encoded string of the legacy
            # shape on v57+ instances.
            legacy_raw = payload.get("legacy_query")
            if isinstance(legacy_raw, str):
                try:
                    legacy_raw = json.loads(legacy_raw)
                except ValueError:
                    legacy_raw = None
            if isinstance(legacy_raw, dict):
                query_type, sql, mbql = cls._parse_legacy_query(legacy_raw)
                if query_type is not None:
                    source = legacy_raw

        collection = payload.get("collection")
        if not isinstance(collection, dict):
            collection_id = payload.get("collection_id")
            collection = {"id": collection_id} if collection_id is not None else None
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            description=payload.get("description"),
            collection=(
                CollectionRef(id=collection["id"], name=collection.get("name"))
                if collection
                else None
            ),
            display=payload.get("display"),
            query_type=query_type,
            database_id=source.get("database"),
            sql=sql,
            mbql=mbql,
            parameters=list(payload.get("parameters") or []),
            created_at=payload.get("created_at"),
            updated_at=payload.get("updated_at"),
            last_edit=LastEdit.from_api(payload.get("last-edit-info")),
        )


@dataclass
class DashboardTab(_models___Model):
    id: int | str | None
    name: str | None


@dataclass
class DashboardParameter(_models___Model):
    id: str | None
    name: str | None
    slug: str | None
    type: str | None
    default: Any = None

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> DashboardParameter:
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            slug=payload.get("slug"),
            type=payload.get("type"),
            default=payload.get("default"),
        )


@dataclass
class CardPosition(_models___Model):
    row: int | None
    col: int | None
    size_x: int | None
    size_y: int | None


@dataclass
class DashboardCard(_models___Model):
    card_id: int | str | None
    name: str | None
    series: list[str] = field(default_factory=list)
    position: CardPosition | None = None
    parameter_mappings: list[Any] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> DashboardCard:
        card = payload.get("card") or {}
        return cls(
            card_id=card.get("id") if isinstance(card, dict) else None,
            name=card.get("name") if isinstance(card, dict) else None,
            series=[s.get("name") for s in (payload.get("series") or []) if isinstance(s, dict)],
            position=CardPosition(
                row=payload.get("row"),
                col=payload.get("col"),
                size_x=payload.get("size_x"),
                size_y=payload.get("size_y"),
            ),
            parameter_mappings=list(payload.get("parameter_mappings") or []),
        )


@dataclass
class DashboardDetail(_models___Model):
    id: int | str
    name: str | None
    description: str | None
    collection: CollectionRef | None
    tabs: list[DashboardTab] = field(default_factory=list)
    parameters: list[DashboardParameter] = field(default_factory=list)
    cards: list[DashboardCard] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: dict[str, Any]) -> DashboardDetail:
        collection = payload.get("collection")
        if not isinstance(collection, dict):
            collection_id = payload.get("collection_id")
            collection = {"id": collection_id} if collection_id is not None else None
        return cls(
            id=payload.get("id"),
            name=payload.get("name"),
            description=payload.get("description"),
            collection=(
                CollectionRef(id=collection["id"], name=collection.get("name"))
                if collection
                else None
            ),
            tabs=[
                DashboardTab(id=tab.get("id"), name=tab.get("name"))
                for tab in (payload.get("tabs") or [])
                if isinstance(tab, dict)
            ],
            parameters=[
                DashboardParameter.from_api(param)
                for param in (payload.get("parameters") or [])
                if isinstance(param, dict)
            ],
            cards=[
                DashboardCard.from_api(dashcard)
                for dashcard in (payload.get("dashcards") or [])
                if isinstance(dashcard, dict)
            ],
        )

models = _ns(
    CardDetail=CardDetail,
    CardPosition=CardPosition,
    CollectionInfo=CollectionInfo,
    CollectionItem=CollectionItem,
    CollectionListing=CollectionListing,
    CollectionRef=CollectionRef,
    ColumnInfo=ColumnInfo,
    DashboardCard=DashboardCard,
    DashboardDetail=DashboardDetail,
    DashboardParameter=DashboardParameter,
    DashboardTab=DashboardTab,
    DatabaseInfo=DatabaseInfo,
    FKTarget=FKTarget,
    FieldInfo=FieldInfo,
    HealthInfo=HealthInfo,
    LastEdit=LastEdit,
    QueryEnvelope=QueryEnvelope,
    SchemaInfo=SchemaInfo,
    SearchItem=SearchItem,
    TableInfo=TableInfo,
    WhoamiInfo=WhoamiInfo,
    _Model=_models___Model,
)


#---------------------------------------------------------------------------
# mbcli.output  (merged: src/mbcli/output.py)
#---------------------------------------------------------------------------
class Format(str, Enum):
    json = "json"
    ndjson = "ndjson"
    csv = "csv"
    table = "table"
    markdown = "markdown"


# Shared command-level data-shaping option types (DESIGN §3.7, §13.4).
FormatOpt = Annotated[
    Format,
    typer.Option("--format", help="输出格式：json（默认）/ ndjson / csv / table / markdown。"),
]
FieldsOpt = Annotated[
    str | None,
    typer.Option(
        "--fields",
        help="逗号分隔的记录键白名单（仅裁剪记录/CSV 列，绝不裁剪查询信封）。",
    ),
]
MaxRowsOpt = Annotated[
    int,
    typer.Option(
        "--max-rows",
        min=0,
        help="客户端行数上限，0 = 不限；截断经 truncated/rows_returned 上报。",
    ),
]
OutOpt = Annotated[
    str | None,
    typer.Option("--out", help="结果写入 FILE；stdout 变为摘要对象。"),
]


def to_jsonable(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return to_jsonable(value.to_dict())
    if isinstance(value, dict):
        return {key: to_jsonable(item) for key, item in value.items()}
    if isinstance(value, list):
        return [to_jsonable(item) for item in value]
    return value


def render_json(data: Any) -> str:
    return json.dumps(to_jsonable(data), ensure_ascii=False)


def parse_fields(fields: str | None) -> list[str] | None:
    if not fields:
        return None
    return [item.strip() for item in fields.split(",") if item.strip()]


def prune_fields(
    records: list[dict[str, Any]], fields: Sequence[str] | None
) -> list[dict[str, Any]]:
    """Prune record keys; a misspelled field is invalid_args (§3.6)."""
    if not fields:
        return records
    if records:
        known: set[str] = set()
        for record in records:
            known.update(record.keys())
        unknown = [name for name in fields if name not in known]
        if unknown:
            raise MbcliError(
                "invalid_args",
                "unknown --fields: " + ", ".join(unknown),
                detail={"unknown": unknown, "available": sorted(known)},
            )
    return [{name: record.get(name) for name in fields} for record in records]


def _output___cell(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool | int | float | str):
        return value
    return json.dumps(to_jsonable(value), ensure_ascii=False)


def render_csv(header: Sequence[str], rows: Sequence[Sequence[Any]]) -> str:
    """RFC 4180 CSV: quote comma/quote/newline fields, double embedded quotes."""
    buffer = io.StringIO()
    writer = csv.writer(buffer, dialect="excel", lineterminator="\r\n")
    writer.writerow(list(header))
    for row in rows:
        writer.writerow([_output___cell(value) for value in row])
    return buffer.getvalue()


def render_ndjson(envelope: dict[str, Any]) -> str:
    """Envelope header line, one row per line, trailing sentinel (§5.2)."""
    lines = [
        json.dumps({"columns": to_jsonable(envelope.get("columns") or [])}, ensure_ascii=False)
    ]
    for row in envelope.get("rows") or []:
        lines.append(json.dumps(to_jsonable(row), ensure_ascii=False))
    lines.append(
        json.dumps(
            {
                "truncated": bool(envelope.get("truncated")),
                "rows_returned": envelope.get("rows_returned"),
            },
            ensure_ascii=False,
        )
    )
    return "\n".join(lines) + "\n"


def render_table(
    header: Sequence[str], rows: Sequence[Sequence[Any]], no_color: bool = False
) -> str:
    buffer = io.StringIO()
    console = Console(file=buffer, no_color=no_color, highlight=False)
    table = RichTable()
    for column in header:
        table.add_column(str(column))
    for row in rows:
        table.add_row(*[str(_output___cell(value)) for value in row])
    console.print(table)
    return buffer.getvalue()


def _output___md_cell(value: Any) -> str:
    """Markdown table cell: pipe and newline escaped so layout stays intact."""
    text = str(_output___cell(value))
    return text.replace("|", "\\|").replace("\n", " ").replace("\r", "")


def render_markdown(header: Sequence[str], rows: Sequence[Sequence[Any]]) -> str:
    """GitHub-style pipe table (§13.4): record keys as the header row,
    `|---|` separator, one row per record. Unicode-safe (no escaping)."""
    lines = [
        "| " + " | ".join(str(name) for name in header) + " |",
        "|" + "|".join("---" for _ in header) + "|",
    ]
    for row in rows:
        lines.append("| " + " | ".join(_output___md_cell(value) for value in row) + " |")
    return "\n".join(lines) + "\n"


def _output___write_stdout(text: str) -> None:
    if not text.endswith("\n"):
        text += "\n"
    sys.stdout.write(text)


def _output___finalize(text: str, out: str | None, rows: int, truncated: bool) -> None:
    if out is None:
        _output___write_stdout(text)
        return
    Path(out).expanduser().write_text(text, encoding="utf-8")
    summary = {"out": str(out), "rows": rows, "truncated": bool(truncated)}
    _output___write_stdout(json.dumps(summary, ensure_ascii=False))


def emit_records(
    records: list[dict[str, Any]],
    *,
    fmt: Format = Format.json,
    fields: str | None = None,
    out: str | None = None,
    truncated: bool = False,
    no_color: bool = False,
) -> None:
    """Emit a record array in any of the five formats (§13.4).

    `truncated=True` means a fetch-level hard cap was hit (e.g. search
    `--limit 0` at 1000 rows): the truncation is annotated in the output
    itself, following the §5.2 philosophy — json becomes an envelope
    `{"truncated": true, "rows_returned": N, "items": […]}`, ndjson gains a
    trailing sentinel line, csv a `#` comment line, table/markdown a final
    marker line. It also feeds the `--out` summary flag.
    """
    field_list = parse_fields(fields)
    pruned = prune_fields(records, field_list)
    if field_list:
        header = list(field_list)
    elif pruned:
        header = list(pruned[0].keys())
    else:
        header = []
    rows = [[record.get(name) for name in header] for record in pruned]
    sentinel = json.dumps({"truncated": True, "rows_returned": len(pruned)}, ensure_ascii=False)
    if fmt is Format.json:
        if truncated:
            text = render_json({"truncated": True, "rows_returned": len(pruned), "items": pruned})
        else:
            text = render_json(pruned)
    elif fmt is Format.csv:
        text = render_csv(header, rows)
        if truncated:
            text += f"# {sentinel}\n"
    elif fmt is Format.ndjson:
        text = "".join(json.dumps(record, ensure_ascii=False) + "\n" for record in pruned)
        if truncated:
            text += sentinel + "\n"
    elif fmt is Format.table:
        text = render_table(header, rows, no_color=no_color)
        if truncated:
            text += sentinel + "\n"
    elif fmt is Format.markdown:
        text = render_markdown(header, rows)
        if truncated:
            text += sentinel + "\n"
    else:  # pragma: no cover - enum exhaustiveness
        raise MbcliError("invalid_args", f"unsupported format: {fmt}")
    _output___finalize(text, out, rows=len(pruned), truncated=truncated)


def emit_envelope(
    envelope: Any,
    *,
    fmt: Format = Format.json,
    fields: str | None = None,
    out: str | None = None,
    no_color: bool = False,
) -> None:
    env = to_jsonable(envelope)
    if not isinstance(env, dict):
        raise MbcliError("invalid_response", "query envelope is not an object")
    if fields:
        raise MbcliError(
            "invalid_args",
            "--fields cannot be applied to a query envelope (envelope keys are never pruned)",
        )
    header = [str(column.get("name")) for column in env.get("columns") or []]
    rows = env.get("rows") or []
    if fmt is Format.json:
        text = render_json(env)
    elif fmt is Format.csv:
        text = render_csv(header, rows)
    elif fmt is Format.ndjson:
        text = render_ndjson(env)
    elif fmt is Format.table:
        text = render_table(header, rows, no_color=no_color)
    elif fmt is Format.markdown:
        text = render_markdown(header, rows)
    else:  # pragma: no cover
        raise MbcliError("invalid_args", f"unsupported format: {fmt}")
    _output___finalize(
        text, out, rows=int(env.get("rows_returned") or 0), truncated=bool(env.get("truncated"))
    )


def emit_object(
    obj: Any,
    *,
    fmt: Format = Format.json,
    out: str | None = None,
    no_color: bool = False,
) -> None:
    """Single-object output (health, whoami): json, table or markdown."""
    data = to_jsonable(obj)
    if fmt is Format.table:
        rows = [[key, _output___cell(value)] for key, value in dict(data).items()]
        text = render_table(["key", "value"], rows, no_color=no_color)
    elif fmt is Format.markdown:
        rows = [[key, _output___cell(value)] for key, value in dict(data).items()]
        text = render_markdown(["key", "value"], rows)
    elif fmt is Format.json:
        text = render_json(data)
    else:
        raise MbcliError(
            "invalid_args",
            f"format '{fmt.value}' is not supported for single-object output;"
            " use json, table or markdown",
        )
    _output___finalize(text, out, rows=1, truncated=False)

output = _ns(
    FieldsOpt=FieldsOpt,
    Format=Format,
    FormatOpt=FormatOpt,
    MaxRowsOpt=MaxRowsOpt,
    OutOpt=OutOpt,
    _cell=_output___cell,
    _finalize=_output___finalize,
    _md_cell=_output___md_cell,
    _write_stdout=_output___write_stdout,
    emit_envelope=emit_envelope,
    emit_object=emit_object,
    emit_records=emit_records,
    parse_fields=parse_fields,
    prune_fields=prune_fields,
    render_csv=render_csv,
    render_json=render_json,
    render_markdown=render_markdown,
    render_ndjson=render_ndjson,
    render_table=render_table,
    to_jsonable=to_jsonable,
)


#---------------------------------------------------------------------------
# mbcli.client  (merged: src/mbcli/client.py)
#---------------------------------------------------------------------------
DEFAULT_RETRY_BACKOFFS: tuple[float, ...] = (0.5, 1.0)
RETRYABLE_STATUSES = frozenset({429, 500, 502, 503, 504})


def one_line(text: str) -> str:
    return " ".join(str(text).split())


class MetabaseClient:
    def __init__(
        self,
        config: Config,
        auth: AuthManager | None = None,
        log: Callable[[str], None] | None = None,
        retry_backoffs: Sequence[float] = DEFAULT_RETRY_BACKOFFS,
    ) -> None:
        self.config = config
        self.auth = auth or AuthManager(config, log=log)
        self.log = log
        self.retry_backoffs = tuple(retry_backoffs)
        self._http = httpx.Client(
            base_url=config.url,
            timeout=config.httpx_timeout(),
            follow_redirects=False,
        )

    # -- public API --------------------------------------------------------

    def get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        auth: bool = True,
        pass_status: Iterable[int] = (),
    ) -> Any:
        """GET and return deserialized JSON. Idempotent: retried on connect
        errors / 429 / 5xx (backoff 0.5s, 1s; max 2 retries)."""
        return self._execute(
            "GET", path, params=params, body=None, use_auth=auth, pass_status=tuple(pass_status)
        )

    def post_json(
        self,
        path: str,
        body: Any,
        *,
        auth: bool = True,
        pass_status: Iterable[int] = (),
    ) -> Any:
        """POST a JSON body and return deserialized JSON. Never retried."""
        return self._execute(
            "POST", path, params=None, body=body, use_auth=auth, pass_status=tuple(pass_status)
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> MetabaseClient:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    # -- internals ----------------------------------------------------------

    def _execute(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None,
        body: Any,
        use_auth: bool,
        pass_status: tuple[int, ...],
    ) -> Any:
        response = self._attempt(method, path, params, body, use_auth, pass_status)
        # 401 handling (§3.2): invalidate + re-login once + replay. The login
        # call itself never goes through this client, so it can never recurse.
        if use_auth and response.status_code == 401:
            if self.auth.uses_api_key:
                raise self._normalize_error(response, path)  # API key 401 is final
            self.auth.invalidate()
            self.auth.auth_headers()  # force re-login; failure -> auth_failed
            response = self._attempt(method, path, params, body, use_auth, pass_status)
        if response.status_code in pass_status:
            return self._parse_json(response)
        return self._checked(response, path)

    def _attempt(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None,
        body: Any,
        use_auth: bool,
        pass_status: tuple[int, ...],
    ) -> httpx.Response:
        headers = self.auth.auth_headers() if use_auth else {}
        backoffs = self.retry_backoffs if method.upper() == "GET" else ()
        tries = 0
        while True:
            try:
                self._log_request(method, path, params, body)
                response = self._http.request(
                    method, path, params=params, json=body, headers=headers
                )
            except httpx.TimeoutException as exc:
                raise MbcliError("timeout", f"request timed out: {one_line(str(exc))}") from exc
            except httpx.ConnectError as exc:
                if tries < len(backoffs):
                    time.sleep(backoffs[tries])
                    tries += 1
                    continue
                raise MbcliError(
                    "network_error", f"connection failed: {one_line(str(exc))}"
                ) from exc
            except httpx.TransportError as exc:
                raise MbcliError("network_error", f"request failed: {one_line(str(exc))}") from exc
            self._log_response(response, path)
            if (
                response.status_code in RETRYABLE_STATUSES
                and response.status_code not in pass_status
                and tries < len(backoffs)
            ):
                time.sleep(backoffs[tries])
                tries += 1
                continue
            return response

    def _checked(self, response: httpx.Response, path: str) -> Any:
        if 200 <= response.status_code < 300:
            return self._parse_json(response)
        raise self._normalize_error(response, path)

    # -- error normalization (DESIGN §3.3 table) ---------------------------

    def _normalize_error(self, response: httpx.Response, path: str) -> MbcliError:
        status = response.status_code
        body = self._try_json(response)
        text = response.text.strip() if response.text else ""

        def body_message() -> str:
            if isinstance(body, dict):
                for key in ("error", "message"):
                    value = body.get(key)
                    if isinstance(value, str) and value.strip():
                        return one_line(value)
            return one_line(text)[:300] if text else ""

        detail: dict[str, Any] = {"http_status": status}

        if status == 401:
            return MbcliError(
                "auth_failed", body_message() or f"authentication failed ({status})", detail
            )
        if status == 403:
            message = body_message()
            return MbcliError(
                "permission_denied", message or f"permission denied ({status})", detail
            )
        if status == 404:
            message = body_message()
            return MbcliError("not_found", message or f"not found: {path}", detail)
        if status in (400, 422):
            if isinstance(body, dict):
                if "error" in body and body.get("status") == "failed":
                    for key in ("error_type", "error_code"):
                        if body.get(key) is not None:
                            detail[key] = body[key]
                    message = body_message() or "query failed"
                    # §13.4 / ADR #22: when the server error points at a MySQL
                    # reserved word, append a backtick hint to error.detail
                    # (user SQL is never rewritten — ADR #4).
                    reserved = find_reserved_token(message)
                    if reserved is not None:
                        detail["reserved_word"] = reserved
                        detail["hint"] = (
                            f"列名 `{reserved}` 为保留字，请用反引号包裹（MySQL 8.0 保留字表）"
                        )
                    return MbcliError("bad_query", message, detail)
                errors = body.get("errors")
                if isinstance(errors, dict):
                    detail["errors"] = errors
                    return MbcliError(
                        "invalid_request", "invalid request: field validation failed", detail
                    )
            return MbcliError(
                "invalid_request", body_message() or f"invalid request ({status})", detail
            )
        if status == 429:
            return MbcliError("rate_limited", body_message() or "rate limited (429)", detail)
        if status >= 500:
            return MbcliError("server_error", body_message() or f"server error ({status})", detail)
        return MbcliError(
            "invalid_request", body_message() or f"unexpected HTTP status {status}", detail
        )

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _try_json(response: httpx.Response) -> Any:
        try:
            return response.json()
        except ValueError:
            return None

    @staticmethod
    def _parse_json(response: httpx.Response) -> Any:
        text = response.text
        if not text.strip():
            return None
        try:
            return json.loads(text)
        except ValueError as exc:
            raise MbcliError(
                "invalid_response",
                "response body is not valid JSON",
                detail={"http_status": response.status_code, "body": text[:200]},
            ) from exc

    def _log_request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None,
        body: Any,
    ) -> None:
        if not self.log:
            return
        line = f"request: {method} {path}"
        if params:
            line += f" params={params}"
        if body is not None:
            line += " body=" + json.dumps(redact_secrets(body), ensure_ascii=False, default=str)
        self.log(line)

    def _log_response(self, response: httpx.Response, path: str) -> None:
        if self.log:
            self.log(f"response: {response.status_code} {path}")

client = _ns(
    DEFAULT_RETRY_BACKOFFS=DEFAULT_RETRY_BACKOFFS,
    MetabaseClient=MetabaseClient,
    RETRYABLE_STATUSES=RETRYABLE_STATUSES,
    one_line=one_line,
)


#---------------------------------------------------------------------------
# mbcli.resolver  (merged: src/mbcli/resolver.py)
#---------------------------------------------------------------------------
def _resolver___is_id(ref: str) -> bool:
    return ref.isdigit()


class Resolver:
    def __init__(self, client: MetabaseClient) -> None:
        self._client = client
        self._db_index: dict[str, list[dict[str, Any]]] | None = None
        self._metadata: dict[int, dict[str, Any]] = {}
        self._collection_index: dict[str, list[dict[str, Any]]] | None = None

    # -- databases ----------------------------------------------------------

    def db(self, ref: str) -> int:
        """Resolve a database ref to its id."""
        if _resolver___is_id(ref):
            return int(ref)
        return self._pick(self._db_name_index().get(ref, []), "database", ref)

    def _db_name_index(self) -> dict[str, list[dict[str, Any]]]:
        if self._db_index is None:
            payload = self._client.get("/api/database")
            data = payload.get("data") if isinstance(payload, dict) else payload
            index: dict[str, list[dict[str, Any]]] = {}
            for item in data or []:
                if isinstance(item, dict) and item.get("name") is not None:
                    index.setdefault(str(item["name"]), []).append(
                        {"id": item.get("id"), "name": item.get("name")}
                    )
            self._db_index = index
        return self._db_index

    # -- tables --------------------------------------------------------------

    def table(self, ref: str, db_id: int | str | None = None) -> int:
        """Resolve a table ref to its id. A table NAME requires db_id."""
        if _resolver___is_id(ref):
            return int(ref)
        if db_id is None:
            raise MbcliError(
                "invalid_args",
                "resolving a table by name requires --db (or pass a numeric table id)",
            )
        db_id = int(db_id)
        metadata = self._db_metadata(db_id)
        tables = metadata.get("tables") or []
        matches = [
            {"id": table.get("id"), "name": table.get("name")}
            for table in tables
            if isinstance(table, dict) and table.get("name") == ref
        ]
        return self._pick(matches, "table", ref)

    def _db_metadata(self, db_id: int) -> dict[str, Any]:
        if db_id not in self._metadata:
            payload = self._client.get(f"/api/database/{db_id}/metadata")
            if not isinstance(payload, dict):
                raise MbcliError("invalid_response", "database metadata response is not an object")
            self._metadata[db_id] = payload
        return self._metadata[db_id]

    # -- collections -----------------------------------------------------------

    def collection(self, ref: str) -> int | str:
        """Resolve a collection ref; the reserved name 'root' maps to 'root'."""
        if ref == "root":
            return "root"
        if _resolver___is_id(ref):
            return int(ref)
        return self._pick(self._collection_name_index().get(ref, []), "collection", ref)

    def _collection_name_index(self) -> dict[str, list[dict[str, Any]]]:
        if self._collection_index is None:
            payload = self._client.get("/api/collection")
            items = payload.get("data") if isinstance(payload, dict) else payload
            index: dict[str, list[dict[str, Any]]] = {}
            for item in items or []:
                if isinstance(item, dict) and item.get("name") is not None:
                    index.setdefault(str(item["name"]), []).append(
                        {"id": item.get("id"), "name": item.get("name")}
                    )
            self._collection_index = index
        return self._collection_index

    # -- shared -----------------------------------------------------------------

    @staticmethod
    def _pick(matches: list[dict[str, Any]], kind: str, ref: str) -> int:
        if not matches:
            raise MbcliError(
                "not_found",
                f"{kind} {ref!r} not found",
                detail={"kind": kind, "ref": ref},
            )
        if len(matches) > 1:
            raise MbcliError(
                "ambiguous_ref",
                f"{kind} name {ref!r} matches {len(matches)} candidates;"
                " use the numeric id instead",
                detail={"kind": kind, "ref": ref, "candidates": matches},
            )
        return int(matches[0]["id"])  # type: ignore[arg-type]

resolver = _ns(
    Resolver=Resolver,
    _is_id=_resolver___is_id,
)


#---------------------------------------------------------------------------
# mbcli.options  (merged: src/mbcli/options.py)
#---------------------------------------------------------------------------
DbRefOpt = Annotated[str, typer.Option("--db", help="数据库 id 或名称。")]
DbHintOpt = Annotated[
    str | None,
    typer.Option("--db", help="数据库 id 或名称（--table 传名称时必填）。"),
]
TableRefOpt = Annotated[str, typer.Option("--table", help="表 id 或名称。")]
IncludeHiddenOpt = Annotated[bool, typer.Option("--include-hidden", help="包含隐藏项。")]
ParamOpt = Annotated[
    list[str] | None,
    typer.Option("--param", help="模板变量参数 k=v（可重复）。"),
]
ModelOpt = Annotated[
    list[str] | None,
    typer.Option("--model", help="资产类型过滤（可重复或逗号分隔）。"),
]


def expand_models(model: list[str] | None) -> list[str]:
    """Flatten repeatable / comma-separated --model values into a flat list.

    Sent as the repeatable `models` (plural) query param — the singular `model=`
    is silently ignored by Metabase (probe-verified, ADR #10). Shared by
    search / collections show (single canonical copy for the amalgam build).
    """
    values: list[str] = []
    for entry in model or []:
        values.extend(part.strip() for part in entry.split(",") if part.strip())
    return values


@dataclass
class CliState:
    """Values provided at the root level for one invocation."""

    url: str | None = None
    api_key: str | None = None
    username: str | None = None
    password: str | None = None
    timeout: int | None = None
    verbose: bool = False
    no_color: bool = False

    def load_config(self) -> Config:
        overrides = {
            key: getattr(self, key)
            for key in ("url", "api_key", "username", "password", "timeout")
            if getattr(self, key) is not None
        }
        return load_config(overrides)

    def log(self, message: str) -> None:
        if self.verbose:
            print(message, file=sys.stderr)

    def build_client(self, config: Config | None = None) -> MetabaseClient:
        config = config or self.load_config()
        return MetabaseClient(config, log=self.log if self.verbose else None)


def state_from_ctx(ctx: typer.Context) -> CliState:
    state = ctx.obj
    return state if isinstance(state, CliState) else CliState()

options = _ns(
    CliState=CliState,
    DbHintOpt=DbHintOpt,
    DbRefOpt=DbRefOpt,
    IncludeHiddenOpt=IncludeHiddenOpt,
    ModelOpt=ModelOpt,
    ParamOpt=ParamOpt,
    TableRefOpt=TableRefOpt,
    expand_models=expand_models,
    state_from_ctx=state_from_ctx,
)


#---------------------------------------------------------------------------
# mbcli.commands.health  (merged: src/mbcli/commands/health.py)
#---------------------------------------------------------------------------
def _health___fetch_version(client: Any) -> str | None:
    """Best-effort version tag from GET /api/session/properties (public)."""
    try:
        properties = client.get("/api/session/properties", auth=False)
    except (MbcliError, httpx.HTTPError):
        return None
    if not isinstance(properties, dict):
        return None
    version = properties.get("version")
    if isinstance(version, dict) and version.get("tag"):
        return str(version["tag"])
    return None


def health(ctx: typer.Context) -> None:
    """实例健康检查（无需凭据）；状态非 ok（含 503 启动中）时 exit 1。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        body = client.get("/api/health", auth=False, pass_status=(503,))
        version = _health___fetch_version(client)
    if not isinstance(body, dict):
        raise MbcliError("invalid_response", "health response is not an object")
    if body.get("status") != "ok":
        raise MbcliError(
            "unhealthy",
            f"Metabase is not healthy: {body.get('status')!r}",
            detail={"body": body},
        )
    emit_object(HealthInfo(status="ok", version=version))


EPILOG = (
    "示例:\n"
    "  mbcli --url https://metabase.example.com health\n"
    "  mbcli health        # connect 过之后无需任何参数"
)

health = _ns(
    EPILOG=EPILOG,
    _fetch_version=_health___fetch_version,
    health=health,
)


#---------------------------------------------------------------------------
# mbcli.commands.whoami  (merged: src/mbcli/commands/whoami.py)
#---------------------------------------------------------------------------
def whoami(
    ctx: typer.Context,
    format: FormatOpt = Format.json,
    out: OutOpt = None,
) -> None:
    """当前认证用户（校验凭据最快的方式）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        payload = client.get("/api/user/current")
    if not isinstance(payload, dict):
        raise MbcliError("invalid_response", "/api/user/current response is not an object")
    emit_object(WhoamiInfo.from_api(payload), fmt=format, out=out, no_color=state.no_color)


EPILOG = "示例:\n  mbcli whoami\n  mbcli whoami --format table"

whoami = _ns(
    EPILOG=EPILOG,
    whoami=whoami,
)


#---------------------------------------------------------------------------
# mbcli.commands.databases  (merged: src/mbcli/commands/databases.py)
#---------------------------------------------------------------------------
app = typer.Typer(help="浏览数据库。", no_args_is_help=True)


@app.command(
    "list",
    epilog=("示例:\n  mbcli databases list\n  mbcli databases list --fields id,name --format csv"),
)
def list_databases(
    ctx: typer.Context,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """列出全部数据库（该端点无分页，一次全量）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        payload = client.get("/api/database")
    data = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(data, list):
        raise MbcliError("invalid_response", "/api/database response has no data array")
    records = [DatabaseInfo.from_api(item).to_dict() for item in data if isinstance(item, dict)]
    emit_records(records, fmt=format, fields=fields, out=out, no_color=state.no_color)

databases = _ns(
    app=app,
    list_databases=list_databases,
)


#---------------------------------------------------------------------------
# mbcli.commands.connect  (merged: src/mbcli/commands/connect.py)
#---------------------------------------------------------------------------
def connect(
    ctx: typer.Context,
    url: Annotated[str | None, typer.Option("--url", help="Metabase 实例根地址。")] = None,
    username: Annotated[str | None, typer.Option("--username", help="登录用户名。")] = None,
    password: Annotated[
        str | None,
        typer.Option("--password", help="登录密码（缺失时隐藏输入补问；建议用 env 而非 argv）。"),
    ] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", help="API Key；优先于用户名/密码。"),
    ] = None,
    default_db: Annotated[
        str | None,
        typer.Option("--default-db", help="保存为 --db 缺省库（id 或名称，经校验后以 id 落盘）。"),
    ] = None,
    non_interactive: Annotated[
        bool,
        typer.Option(
            "--non-interactive",
            help="绝不交互补问；缺任何字段直接 exit 2（agent/脚本路径）。",
        ),
    ] = False,
    force: Annotated[bool, typer.Option("--force", help="允许覆盖一个不同的已有连接。")] = False,
) -> None:
    """校验凭据并持久化连接到 config.toml（之后所有命令零连接参数）。

    逐字段取值：CLI 参数 > MB_* 环境变量 > 交互式补问（仅当前两者皆缺才提示，
    密码隐藏输入）。先验证（密码模式登录+whoami / API Key 模式 whoami）后落盘：
    任何失败不写任何内容；成功会连带废弃 session 缓存。覆盖不同的旧连接需
    --force，同一连接重连（如改密码）无需。
    """
    state = state_from_ctx(ctx)
    overrides = {
        key: getattr(state, key)
        for key in ("url", "api_key", "username", "password", "timeout")
        if getattr(state, key) is not None
    }
    # lenient load: the URL may be missing here (connect prompts for it);
    # lower-priority sources still contribute username/password/api_key/paths.
    base = load_config(overrides, require_url=False)

    # Mode intent: connect's own credential flags decide the mode, and values of
    # the OTHER mode from lower-priority sources are ignored — switching from a
    # saved api-key connection to username/password (or vice versa) never needs
    # manual file editing.
    if api_key is not None:
        key_mode = True
        username = password = None
    elif username is not None or password is not None:
        key_mode = False
        api_key = None
        username = username or base.username
        password = password or base.password
    elif base.api_key:
        key_mode, api_key = True, base.api_key
    else:
        key_mode = False
        username, password = base.username, base.password
    url = url or base.url

    missing = []
    if not url:
        missing.append("--url")
    if key_mode:
        if not api_key:
            missing.append("--api-key")
    else:
        if not username:
            missing.append("--username")
        if not password:
            missing.append("--password")
    if non_interactive and missing:
        raise MbcliError(
            "invalid_args",
            "connect: missing " + ", ".join(missing) + " (--non-interactive never prompts;"
            " pass the flags or set MB_URL/MB_USERNAME/MB_PASSWORD/MB_API_KEY)",
        )
    if not url:
        url = typer.prompt("Metabase URL")
    if not key_mode:
        username = username or typer.prompt("Username")
        password = password or typer.prompt("Password", hide_input=True)
    elif not api_key:
        api_key = typer.prompt("API key", hide_input=True)
    url = url.rstrip("/")

    # VALIDATE BEFORE SAVE: password mode -> login + whoami; key mode -> whoami.
    validation_config = Config(
        url=url,
        api_key=api_key if key_mode else None,
        username=None if key_mode else username,
        password=None if key_mode else password,
        timeout=base.timeout,
        session_cache=base.session_cache,
    )
    with state.build_client(validation_config) as client:
        user = client.get("/api/user/current")
        db_info = _connect___resolve_default_db(client, default_db) if default_db else None
    if not isinstance(user, dict):
        raise MbcliError("invalid_response", "/api/user/current response is not an object")

    # Overwrite protection: a DIFFERENT connection (url or identity) needs --force;
    # the same connection may reconnect freely (e.g. after a password change).
    existing = parse_toml(base.config_file)
    old_url = existing.get("url")
    old_identity = existing.get("api_key") or existing.get("username")
    was_connected = bool(old_url and old_identity)
    if was_connected and not force:
        same_connection = old_url == url and (
            (api_key and existing.get("api_key") == api_key)
            or (
                not api_key and not existing.get("api_key") and existing.get("username") == username
            )
        )
        if not same_connection:
            raise MbcliError(
                "invalid_args",
                f"config file already holds a different connection ({old_url});"
                " re-run with --force to replace it",
                detail={"config_file": str(base.config_file), "existing_url": old_url},
            )

    values: dict[str, Any] = {"url": url}
    if key_mode:
        values["api_key"] = api_key
    else:
        values["username"] = username
        values["password"] = password
    if db_info is not None:
        values["default_db"] = str(db_info["id"])  # store the id: resolves deterministically
    save_metabase_section(base.config_file, values)
    _connect___unlink(base.session_cache)  # the old session belongs to the old connection

    typer.echo(
        render_json(
            {
                "connected": True,
                "url": url,
                "user": {"id": user.get("id"), "email": user.get("email")},
                "default_db": db_info,
                "replaced": old_url if was_connected else None,
                "config_file": str(Path(base.config_file).expanduser()),
            }
        )
    )


def disconnect(ctx: typer.Context) -> None:
    """忘记已保存的连接：删除 config.toml 的 \\[metabase] 段与 session 缓存；幂等，恒 exit 0。"""
    config = load_config(None, require_url=False)
    config_file = Path(config.config_file).expanduser()
    existing = parse_toml(config_file)
    was_connected = bool(
        existing.get("url") and (existing.get("api_key") or existing.get("username"))
    )
    remove_metabase_section(config_file)
    cache_path = Path(config.session_cache).expanduser()
    cache_cleared = cache_path.is_file()
    if cache_cleared:
        _connect___unlink(cache_path)
    typer.echo(
        render_json(
            {
                "disconnected": True,
                "was_connected": was_connected,
                "session_cache_cleared": cache_cleared,
            }
        )
    )


EPILOG = (
    "示例:\n"
    "  mbcli connect --url https://metabase.example.com --username me@example.com"
    " --default-db quant_data\n"
    "  MB_URL=… MB_USERNAME=… MB_PASSWORD=… mbcli connect --non-interactive"
    "   # 全靠环境变量\n"
    "  mbcli connect --password 新密码        # 同一连接改密重连，无需 --force"
)

DISCONNECT_EPILOG = "示例:\n  mbcli disconnect\n  MB_CONFIG_FILE=/tmp/other.toml mbcli disconnect   # 操作另一份配置文件"


# -- helpers ---------------------------------------------------------------------------


def _connect___resolve_default_db(client: Any, ref: str) -> dict[str, Any]:
    """Validate --default-db against GET /api/database (existence is checked for
    ids too) and return {"id":…,"name":…}."""
    payload = client.get("/api/database")
    data = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(data, list):
        raise MbcliError("invalid_response", "/api/database response has no data array")
    if ref.isdigit():
        db_id = int(ref)
        for item in data:
            if isinstance(item, dict) and item.get("id") == db_id:
                return {"id": db_id, "name": item.get("name")}
        raise MbcliError(
            "not_found",
            f"database id {ref} not found",
            detail={"kind": "database", "ref": ref},
        )
    matches = [item for item in data if isinstance(item, dict) and item.get("name") == ref]
    if not matches:
        raise MbcliError(
            "not_found",
            f"database {ref!r} not found",
            detail={"kind": "database", "ref": ref},
        )
    if len(matches) > 1:
        raise MbcliError(
            "ambiguous_ref",
            f"database name {ref!r} matches {len(matches)} candidates; use the numeric id",
            detail={
                "kind": "database",
                "ref": ref,
                "candidates": [{"id": m.get("id"), "name": m.get("name")} for m in matches],
            },
        )
    return {"id": matches[0].get("id"), "name": ref}


def _connect___unlink(path: str | Path) -> None:
    """Best-effort file removal (missing files are fine; never fatal)."""
    try:
        Path(path).expanduser().unlink(missing_ok=True)
    except OSError:
        pass

connect = _ns(
    DISCONNECT_EPILOG=DISCONNECT_EPILOG,
    EPILOG=EPILOG,
    _resolve_default_db=_connect___resolve_default_db,
    _unlink=_connect___unlink,
    connect=connect,
    disconnect=disconnect,
)


#---------------------------------------------------------------------------
# mbcli.commands.schemas  (merged: src/mbcli/commands/schemas.py)
#---------------------------------------------------------------------------
EPILOG = (
    "示例:\n"
    "  mbcli schemas --db quant_data\n"
    "  mbcli schemas        # 使用 connect --default-db 保存的缺省库"
)


DB_HELP = "数据库 id 或名称（缺省回退：已连接的 default_db / MB_DEFAULT_DB）。"


def schemas(
    ctx: typer.Context,
    db: Annotated[str | None, typer.Option("--db", help=DB_HELP)] = None,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """列出数据库的全部 schema（MySQL 通常仅有 ''）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    db_ref = effective_db_ref(db, config)
    with state.build_client(config) as client:
        resolver = Resolver(client)
        db_id = resolver.db(db_ref)
        # Single GET /api/database/{id}/metadata, reused from the Resolver's
        # process cache (DESIGN §0: one call returns the full tables[] list).
        metadata = resolver._db_metadata(db_id)
    counts: Counter[str] = Counter()
    for table in metadata.get("tables") or []:
        if isinstance(table, dict):
            counts[str(table.get("schema") or "")] += 1
    records = [
        SchemaInfo(name=name, table_count=count).to_dict() for name, count in sorted(counts.items())
    ]
    emit_records(records, fmt=format, fields=fields, out=out, no_color=state.no_color)

schemas = _ns(
    DB_HELP=DB_HELP,
    EPILOG=EPILOG,
    schemas=schemas,
)


#---------------------------------------------------------------------------
# mbcli.commands.tables  (merged: src/mbcli/commands/tables.py)
#---------------------------------------------------------------------------
EPILOG = (
    "示例:\n"
    "  mbcli tables --db quant_data --match mau\n"
    "  mbcli tables --fields id,name,estimated_row_count --format csv"
)


def _tables___load_metadata(
    resolver: Resolver, client: MetabaseClient, db_id: int, include_hidden: bool
) -> dict[str, Any]:
    """Default path reuses the Resolver's process cache (one metadata GET);
    --include-hidden refetches with include_hidden=true so hidden tables appear."""
    if not include_hidden:
        return resolver._db_metadata(db_id)
    payload = client.get(f"/api/database/{db_id}/metadata", params={"include_hidden": "true"})
    if not isinstance(payload, dict):
        raise MbcliError("invalid_response", "database metadata response is not an object")
    return payload


def _tables___visible(table: dict[str, Any]) -> bool:
    """Without --include-hidden: drop inactive tables and any non-null visibility_type."""
    return bool(table.get("active", True)) and not table.get("visibility_type")


def tables(
    ctx: typer.Context,
    db: Annotated[
        str | None,
        typer.Option(
            "--db",
            help="数据库 id 或名称（缺省回退：已连接的 default_db / MB_DEFAULT_DB）。",
        ),
    ] = None,
    schema: Annotated[str | None, typer.Option("--schema", help="按 schema 名称过滤。")] = None,
    match: Annotated[
        str | None, typer.Option("--match", help="表名子串过滤（不区分大小写）。")
    ] = None,
    include_hidden: IncludeHiddenOpt = False,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """列出库内数据表（单次 metadata 调用，进程内缓存；行数为同步估值，仅供参考）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    db_ref = effective_db_ref(db, config)
    with state.build_client(config) as client:
        resolver = Resolver(client)
        db_id = resolver.db(db_ref)
        metadata = _tables___load_metadata(resolver, client, db_id, include_hidden)
    entries = [table for table in metadata.get("tables") or [] if isinstance(table, dict)]
    if not include_hidden:
        entries = [table for table in entries if _tables___visible(table)]
    if schema is not None:
        entries = [table for table in entries if table.get("schema") == schema]
    if match is not None:
        needle = match.lower()
        entries = [table for table in entries if needle in str(table.get("name") or "").lower()]
    records = [TableInfo.from_api(table).to_dict() for table in entries]
    emit_records(records, fmt=format, fields=fields, out=out, no_color=state.no_color)

tables = _ns(
    EPILOG=EPILOG,
    _load_metadata=_tables___load_metadata,
    _visible=_tables___visible,
    tables=tables,
)


#---------------------------------------------------------------------------
# mbcli.commands.fields  (merged: src/mbcli/commands/fields.py)
#---------------------------------------------------------------------------
EPILOG = (
    "示例:\n"
    "  mbcli fields --table app_mau --db quant_data\n"
    "  mbcli fields --table 3258        # 数字表 id 无需 --db\n"
    "  mbcli fields --search year_month --db 15   # 跨表列搜索（零额外请求）"
)


def _fields___to_field_info(payload: dict[str, Any]) -> FieldInfo:
    """§5.1 `position` reports the physical column ordinal, which query_metadata
    carries as `database_position` (its `position` is the UI ordering override),
    so normalize the key before the whitelist mapping in models.FieldInfo."""
    return FieldInfo.from_api({**payload, "position": payload.get("database_position")})


def _fields___field_index(
    tables: list[dict[str, Any]],
) -> dict[Any, tuple[str | None, str | None]]:
    """field id -> (table name, field name) across the whole metadata response;
    used to back-resolve `fk_target_field_id` with zero extra requests."""
    index: dict[Any, tuple[str | None, str | None]] = {}
    for table in tables:
        table_name = table.get("name")
        for field in table.get("fields") or []:
            if isinstance(field, dict) and field.get("id") is not None:
                index[field["id"]] = (str(table_name), field.get("name"))
    return index


def _fields___visible(table: dict[str, Any]) -> bool:
    """Without --include-hidden: drop inactive tables and non-null visibility_type."""
    return bool(table.get("active", True)) and not table.get("visibility_type")


def _fields___column_search_records(
    metadata: dict[str, Any], needle: str, include_hidden: bool
) -> list[dict[str, Any]]:
    """§13.4 cross-table column search rows, in metadata order (deterministic)."""
    lowered = needle.lower()
    tables = [item for item in metadata.get("tables") or [] if isinstance(item, dict)]
    index = _fields___field_index(tables)
    records: list[dict[str, Any]] = []
    for table in tables:
        if not include_hidden and not _fields___visible(table):
            continue
        for field in table.get("fields") or []:
            if not isinstance(field, dict):
                continue
            name = str(field.get("name") or "")
            if lowered not in name.lower():
                continue
            fk_target: dict[str, Any] | None = None
            fk_id = field.get("fk_target_field_id")
            if fk_id in index:
                target_table, target_field = index[fk_id]
                fk_target = {"table": target_table, "field": target_field}
            records.append(
                {
                    "table": table.get("name"),
                    "table_id": table.get("id"),
                    "column": field.get("name"),
                    "base_type": field.get("base_type"),
                    "semantic_type": field.get("semantic_type"),
                    "is_pk": bool(field.get("database_is_pk", False)),
                    "fk_target": fk_target,
                    "reserved": is_reserved(name),
                }
            )
    return records


def fields(
    ctx: typer.Context,
    table: Annotated[
        str | None,
        typer.Option("--table", help="表 id 或名称（与 --search 互斥）。"),
    ] = None,
    db: Annotated[
        str | None,
        typer.Option(
            "--db",
            help="数据库 id 或名称；表名/列搜索必填（或已有缺省库）。"
            "数字表 id 可独立使用，无需任何 db。",
        ),
    ] = None,
    search: Annotated[
        str | None,
        typer.Option(
            "--search",
            help="跨表列名子串搜索（需 --db；扫 metadata 全表字段，零额外请求）。",
        ),
    ] = None,
    include_hidden: IncludeHiddenOpt = False,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """列出表字段（含已水合的 FK 目标；position 为物理列序）或跨表搜索列名。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    if search is not None and table is not None:
        raise MbcliError("invalid_args", "--search and --table are mutually exclusive")
    if search is None and table is None:
        raise MbcliError("invalid_args", "exactly one of --table or --search is required")
    if search is not None:
        if not search.strip():
            raise MbcliError("invalid_args", "--search must be a non-empty substring")
        # column search is scoped to one database (name or id; no default-free
        # numeric shortcut like --table <id>)
        db_ref = effective_db_ref(db, config)
        with state.build_client(config) as client:
            resolver = Resolver(client)
            db_id = resolver.db(db_ref)
            metadata = resolver._db_metadata(db_id)
        records = _fields___column_search_records(metadata, search.strip(), include_hidden)
        emit_records(records, fmt=format, fields=fields, out=out, no_color=state.no_color)
        return
    # single-table mode
    # --db > default_db fallback; a NUMERIC table id still resolves standalone.
    if db is not None:
        db_ref: str | None = db
    elif config.default_db:
        db_ref = str(config.default_db)
    elif table.isdigit():
        db_ref = None
    else:
        raise MbcliError("invalid_args", NO_DB_MESSAGE)
    with state.build_client(config) as client:
        resolver = Resolver(client)
        db_id = resolver.db(db_ref) if db_ref is not None else None
        table_id = resolver.table(table, db_id=db_id)
        params = {"include_hidden_fields": "true"} if include_hidden else None
        payload = client.get(f"/api/table/{table_id}/query_metadata", params=params)
    if not isinstance(payload, dict):
        raise MbcliError("invalid_response", "table query_metadata response is not an object")
    entries = [item for item in payload.get("fields") or [] if isinstance(item, dict)]
    records = [_fields___to_field_info(entry).to_dict() for entry in entries]
    emit_records(records, fmt=format, fields=fields, out=out, no_color=state.no_color)

fields = _ns(
    EPILOG=EPILOG,
    _column_search_records=_fields___column_search_records,
    _field_index=_fields___field_index,
    _to_field_info=_fields___to_field_info,
    _visible=_fields___visible,
    fields=fields,
)


#---------------------------------------------------------------------------
# mbcli.commands.query  (merged: src/mbcli/commands/query.py)
#---------------------------------------------------------------------------
EPILOG = (
    "示例:\n"
    '  mbcli query --db 15 --native "SELECT 1 AS one"\n'
    '  mbcli query --db quant_data --native "SELECT * FROM app_mau LIMIT 3"'
    " --format csv --max-rows 100\n"
    '  mbcli query --native "SELECT count(*) FROM app_mau WHERE date={{dt}}"'
    " --param dt=2023-07-01"
)


def native_parameters(params: list[str] | None) -> list[dict[str, Any]]:
    """Serialize repeatable `--param k=v` options into dataset parameters.

    M2 scope (DESIGN §4): native template VARIABLES only — every param maps to
    {"type":"category","target":["variable",["template-tag",k]],"value":v}.
    The value is passed through verbatim (always a string); `k` may not be
    empty and the `k=v` shape is mandatory (invalid_args, exit 2).
    """
    parameters: list[dict[str, Any]] = []
    for item in params or []:
        key, sep, value = item.partition("=")
        if not sep or not key:
            raise MbcliError(
                "invalid_args",
                f"invalid --param {item!r}: expected k=v",
                detail={"param": item},
            )
        parameters.append(
            {"type": "category", "target": ["variable", ["template-tag", key]], "value": value}
        )
    return parameters


def envelope_from_payload(payload: Any, max_rows: int) -> QueryEnvelope:
    """Model a /api/dataset-style response with client-side truncation (§5.2)."""
    if not isinstance(payload, dict):
        raise MbcliError("invalid_response", "dataset response is not an object")
    return QueryEnvelope.from_response(payload, max_rows=max_rows)


def query(
    ctx: typer.Context,
    native: Annotated[
        str,
        typer.Option(
            "--native",
            help="要执行的 SQL；非 SELECT 语句默认拒绝（写保护先于任何网络请求执行）。",
        ),
    ],
    db: Annotated[
        str | None,
        typer.Option(
            "--db",
            help="数据库 id 或名称（缺省回退：已连接的 default_db / MB_DEFAULT_DB）。",
        ),
    ] = None,
    param: ParamOpt = None,
    allow_write: Annotated[
        bool,
        typer.Option(
            "--allow-write",
            help="绕过只读写保护（确认语句安全后才使用）。",
        ),
    ] = False,
    format: FormatOpt = Format.json,
    max_rows: MaxRowsOpt = 1000,
    out: OutOpt = None,
    fields: FieldsOpt = None,
) -> None:
    """执行原生 SQL（默认只读；服务端忽略请求级限量，--max-rows 为客户端截断）。"""
    guard.check_readonly(native, allow_write)  # before ANY config/network work (§3.4)
    parameters = native_parameters(param)  # cheap validation, no I/O
    state = state_from_ctx(ctx)
    config = state.load_config()
    db_ref = effective_db_ref(db, config)
    with state.build_client(config) as client:
        db_id = Resolver(client).db(db_ref)
        payload = client.post_json(
            "/api/dataset",
            {
                "database": db_id,
                "type": "native",
                "native": {"query": native, "template-tags": {}},
                "parameters": parameters,
            },
        )
    emit_envelope(
        envelope_from_payload(payload, max_rows),
        fmt=format,
        fields=fields,
        out=out,
        no_color=state.no_color,
    )

query = _ns(
    EPILOG=EPILOG,
    envelope_from_payload=envelope_from_payload,
    native_parameters=native_parameters,
    query=query,
)


#---------------------------------------------------------------------------
# mbcli.commands.cards  (merged: src/mbcli/commands/cards.py)
#---------------------------------------------------------------------------
app = typer.Typer(help="执行或查看已保存的问题（卡片）。", no_args_is_help=True)


@app.command(
    "run",
    epilog=(
        "示例:\n"
        "  mbcli cards run 7876\n"
        "  mbcli cards run 7876 --format csv --max-rows 100 --out result.csv"
    ),
)
def run(
    ctx: typer.Context,
    card_id: Annotated[int, typer.Argument(help="卡片 id。")],
    param: ParamOpt = None,
    format: FormatOpt = Format.json,
    max_rows: MaxRowsOpt = 1000,
    out: OutOpt = None,
    fields: FieldsOpt = None,
) -> None:
    """执行已保存的卡片（输出与 query 相同的信封）。"""
    parameters = native_parameters(param)
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        payload = client.post_json(
            f"/api/card/{card_id}/query",
            {"parameters": parameters, "ignore_cache": False},
        )
    emit_envelope(
        envelope_from_payload(payload, max_rows),
        fmt=format,
        fields=fields,
        out=out,
        no_color=state.no_color,
    )


@app.command(
    "show",
    epilog=("示例:\n  mbcli cards show 7876\n  mbcli cards show 7876 --fields id,name,sql"),
)
def show(
    ctx: typer.Context,
    card_id: Annotated[int, typer.Argument(help="卡片 id。")],
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """查看卡片定义（SQL/MBQL/参数/集合），不执行。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        payload = client.get(f"/api/card/{card_id}")
    if not isinstance(payload, dict):
        raise MbcliError("invalid_response", "/api/card response is not an object")
    card = CardDetail.from_api(payload).to_dict()
    field_list = parse_fields(fields)
    if field_list:
        card = prune_fields([card], field_list)[0]
    emit_object(card, fmt=format, out=out, no_color=state.no_color)

cards = _ns(
    app=app,
    run=run,
    show=show,
)


#---------------------------------------------------------------------------
# mbcli.commands.collections  (merged: src/mbcli/commands/collections.py)
#---------------------------------------------------------------------------
app = typer.Typer(help="浏览集合及其内容。", no_args_is_help=True)


@app.command(
    "list",
    epilog=(
        "示例:\n"
        "  mbcli collections list --fields id,name\n"
        "  mbcli collections list --all --format csv"
    ),
)
def list_collections(
    ctx: typer.Context,
    all: Annotated[bool, typer.Option("--all", help="包含个人集合（默认被过滤掉）。")] = False,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """列出集合（默认隐藏个人集合）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        payload = client.get("/api/collection")
    data = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(data, list):
        raise MbcliError("invalid_response", "/api/collection response is not an array")
    records: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        info = CollectionInfo.from_api(item)
        if not all and info.is_personal:
            continue
        records.append(info.to_dict())
    emit_records(records, fmt=format, fields=fields, out=out, no_color=state.no_color)


@app.command(
    "show",
    epilog=(
        "示例:\n"
        "  mbcli collections show root --model card --limit 20\n"
        "  mbcli collections show 1039 --model card,dashboard --offset 20"
    ),
)
def show(
    ctx: typer.Context,
    ref: Annotated[str, typer.Argument(help="集合 id、名称或保留字 'root'。")],
    model: ModelOpt = None,
    limit: Annotated[int | None, typer.Option("--limit", min=1, help="页大小。")] = None,
    offset: Annotated[int | None, typer.Option("--offset", min=0, help="翻页偏移。")] = None,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """列出集合内容（分页信封 total/limit/offset/items；--model 以复数 models 参数发给服务端）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        collection_id = Resolver(client).collection(ref)
        params: dict[str, Any] = {}
        models = expand_models(model)
        if models:
            params["models"] = models
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        payload = client.get(f"/api/collection/{collection_id}/items", params)
    if not isinstance(payload, dict):
        raise MbcliError("invalid_response", "collection items response is not an object")
    items = [
        CollectionItem.from_api(item)
        for item in payload.get("data") or []
        if isinstance(item, dict)
    ]
    record = CollectionListing.from_api(payload, items=items).to_dict()
    # §13.4 format audit: json keeps the {total,limit,offset,items} envelope;
    # the tabular formats (csv/ndjson/table/markdown) render the items[] record
    # array itself — with --fields selecting item keys / columns.
    if format is Format.json:
        if fields:
            # --fields prunes the item records only; envelope keys stay intact (§3.6)
            record["items"] = prune_fields(record["items"], parse_fields(fields))
        emit_object(record, fmt=format, out=out, no_color=state.no_color)
    else:
        emit_records(record["items"], fmt=format, fields=fields, out=out, no_color=state.no_color)

collections = _ns(
    app=app,
    list_collections=list_collections,
    show=show,
)


#---------------------------------------------------------------------------
# mbcli.commands.dashboards  (merged: src/mbcli/commands/dashboards.py)
#---------------------------------------------------------------------------
app = typer.Typer(help="查看仪表盘。", no_args_is_help=True)


@app.command(
    "show",
    epilog=(
        "示例:\n  mbcli dashboards show 1607\n  mbcli dashboards show 1607 --fields id,name,cards"
    ),
)
def show(
    ctx: typer.Context,
    dashboard_id: Annotated[int, typer.Argument(help="仪表盘 id。")],
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """查看仪表盘结构（tabs/parameters/cards 含位置与参数映射），不执行任何卡片。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        payload = client.get(f"/api/dashboard/{dashboard_id}")
    if not isinstance(payload, dict):
        raise MbcliError("invalid_response", "dashboard response is not an object")
    record = DashboardDetail.from_api(payload).to_dict()
    if fields:
        # treat the single detail object as a one-record list: unknown key -> invalid_args
        record = prune_fields([record], parse_fields(fields))[0]
    emit_object(record, fmt=format, out=out, no_color=state.no_color)

dashboards = _ns(
    app=app,
    show=show,
)


#---------------------------------------------------------------------------
# mbcli.commands.search  (merged: src/mbcli/commands/search.py)
#---------------------------------------------------------------------------
# fetch-all contract (§13.4): client paging, page size 100, hard cap 1000 rows
FETCH_PAGE_SIZE = 100
FETCH_HARD_CAP = 1000

EPILOG = (
    "示例:\n"
    "  mbcli search 数据 --limit 3\n"
    "  mbcli search 收入 --model card,dashboard --limit 10\n"
    "  mbcli search 手机,mobile,phone --match-any --limit 5   # 多关键词并集去重\n"
    "  mbcli search 用户 --limit 0                            # 拉全集（页 100，上限 1000）"
)


def split_keywords(query: str) -> list[str]:
    """Split a `--match-any` QUERY into non-empty comma-separated keywords."""
    return [part.strip() for part in query.split(",") if part.strip()]


def _search___extract_data(payload: Any) -> list[dict[str, Any]]:
    data = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(data, list):
        raise MbcliError("invalid_response", "/api/search response has no data array")
    return [item for item in data if isinstance(item, dict)]


def _search___matches_db(item: dict[str, Any], db_id: int) -> bool:
    # page-local client filter: cards carry `database_id`, table-model items
    # carry `table_db_id`; items with neither key cannot match a database.
    return item.get("database_id") == db_id or item.get("table_db_id") == db_id


def _search___fetch_keyword_pool(
    client: MetabaseClient,
    keyword: str,
    models: list[str],
    db_id: int | None,
    start_offset: int,
    stop_after: int,
) -> tuple[list[dict[str, Any]], bool]:
    """Paged fetch for one keyword until the pool reaches `stop_after` items
    (post-db-filter) or the result set is exhausted.

    Returns (items, exhausted). exhausted=False means the budget stopped us
    while full pages kept coming — the full set may be larger. The offset
    advances by the number of rows actually returned, so servers that clamp
    the page size below the requested one do not cause rows to be skipped.
    """
    pool: list[dict[str, Any]] = []
    offset = start_offset
    while True:
        page_size = min(FETCH_PAGE_SIZE, stop_after)
        params: dict[str, Any] = {"q": keyword, "limit": page_size, "offset": offset}
        if models:
            params["models"] = models
        payload = client.get("/api/search", params)
        data = _search___extract_data(payload)
        pool.extend(item for item in data if db_id is None or _search___matches_db(item, db_id))
        total = payload.get("total") if isinstance(payload, dict) else None
        offset += len(data)
        end_reached = (
            not data or len(data) < page_size or (isinstance(total, int) and offset >= total)
        )
        if end_reached:
            return pool, True
        if len(pool) >= stop_after:
            return pool, False  # budget reached; more may exist


def search(
    ctx: typer.Context,
    query: Annotated[str, typer.Argument(help="检索关键词；--match-any 时为逗号分隔多关键词。")],
    model: ModelOpt = None,
    db: Annotated[
        str | None,
        typer.Option(
            "--db",
            help="库 id 或名称；仅对返回页做客户端过滤"
            "（card 匹配 database_id，table 匹配 table_db_id）。",
        ),
    ] = None,
    limit: Annotated[
        int | None,
        typer.Option(
            "--limit",
            min=0,
            help="页大小（服务端默认 50）；0 = 拉全集（客户端翻页，页 100，"
            f"硬上限 {FETCH_HARD_CAP} 行，超限在输出尾标注 truncated）。",
        ),
    ] = None,
    offset: Annotated[int | None, typer.Option("--offset", min=0, help="翻页偏移。")] = None,
    match_any: Annotated[
        bool,
        typer.Option(
            "--match-any",
            help="把 QUERY 视为逗号分隔多关键词：各取结果后按 (model,id) 去重合并。",
        ),
    ] = False,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """全局检索资产（卡片/仪表盘/集合/表），Agent 定位资产的入口。

    服务端 search 不支持按库过滤：--db 是对返回页的客户端过滤，超出 --limit
    的结果不会扫到；按库找表请用 `mbcli tables --db D --match`。
    """
    state = state_from_ctx(ctx)
    config = state.load_config()
    if match_any:
        keywords = split_keywords(query)
        if not keywords:
            raise MbcliError("invalid_args", "--match-any needs at least one non-empty keyword")
    else:
        keywords = [query]
    start_offset = offset or 0
    with state.build_client(config) as client:
        resolver = Resolver(client)
        db_id = resolver.db(db) if db is not None else None
        models = expand_models(model)
        merged: list[dict[str, Any]] = []
        seen: set[tuple[Any, Any]] = set()
        fetch_truncated = False

        if not match_any and limit != 0:
            # single-page path — request params and page-local semantics stay
            # exactly as the v0.1 contract (DESIGN §4: --db filters this page)
            params: dict[str, Any] = {"q": query}
            if models:
                params["models"] = models
            if limit is not None:
                params["limit"] = limit
            if offset is not None:
                params["offset"] = offset
            payload = client.get("/api/search", params)
            items = _search___extract_data(payload)
            if db_id is not None:
                items = [item for item in items if _search___matches_db(item, db_id)]
            merged = items
        else:
            # --match-any merge and/or --limit 0 fetch-all (§13.4): paged fetch
            # per keyword, dedupe by (model, id) in first-seen order. With an
            # explicit --limit N>0 the merged output is capped at N — the top-N
            # of a merged dedup can only contain items from the first N of each
            # keyword's own list, so the per-keyword budget is N (bounded by
            # the hard cap; hitting the cap annotates the output as truncated).
            display_cap = limit if (limit is not None and limit > 0) else None
            budget = min(display_cap, FETCH_HARD_CAP) if display_cap else FETCH_HARD_CAP
            for keyword in keywords:
                pool, _exhausted = _search___fetch_keyword_pool(
                    client, keyword, models, db_id, start_offset, budget
                )
                for item in pool:
                    key = (item.get("model"), item.get("id"))
                    if key not in seen:
                        seen.add(key)
                        merged.append(item)
                if len(merged) >= FETCH_HARD_CAP:
                    # hard cap reached — always annotate. Even when the server
                    # reported total == 1000 and every page came back, a
                    # server-side total cap (observed live: broad queries
                    # report exactly 1000) makes "complete" indistinguishable
                    # from "at least 1000", so agents must be warned.
                    fetch_truncated = True
                    merged = merged[:FETCH_HARD_CAP]
                    break

        records = [SearchItem.from_api(item).to_dict() for item in merged]
    if match_any and limit is not None and limit > 0:
        records = records[:limit]  # display cap over the merged, deduped pool
    emit_records(
        records,
        fmt=format,
        fields=fields,
        out=out,
        truncated=fetch_truncated,
        no_color=state.no_color,
    )

search = _ns(
    EPILOG=EPILOG,
    FETCH_HARD_CAP=FETCH_HARD_CAP,
    FETCH_PAGE_SIZE=FETCH_PAGE_SIZE,
    _extract_data=_search___extract_data,
    _fetch_keyword_pool=_search___fetch_keyword_pool,
    _matches_db=_search___matches_db,
    search=search,
    split_keywords=split_keywords,
)


#---------------------------------------------------------------------------
# mbcli.commands.context  (merged: src/mbcli/commands/context.py)
#---------------------------------------------------------------------------
# exact footnote line from DESIGN §6 — the ¹ marks estimated_row_count as approximate
FOOTNOTE = "¹ estimated_row_count 为 Metabase 同步估值，仅作参考"

EPILOG = (
    "示例:\n"
    "  mbcli context --db 15 --table app_mau\n"
    "  mbcli context --db quant_data --max-tables 10 > schema.md\n"
    "  mbcli context --include-fields-pattern '^(uid|id)$' --json"
)


def context(
    ctx: typer.Context,
    db: Annotated[
        str | None,
        typer.Option(
            "--db",
            help="数据库 id 或名称（缺省回退：已连接的 default_db / MB_DEFAULT_DB）。",
        ),
    ] = None,
    table: Annotated[
        list[str] | None,
        typer.Option(
            "--table",
            help="限定到指定表（可重复，按给定顺序输出）；缺省=全库按表名字典序取前 N 张。",
        ),
    ] = None,
    max_tables: Annotated[
        int,
        typer.Option("--max-tables", min=1, help="未指定 --table 时按表名排序取前 N 张。"),
    ] = 50,
    include_fields_pattern: Annotated[
        str,
        typer.Option(
            "--include-fields-pattern",
            help="字段名正则过滤（Python re.search 部分匹配语义），防宽表爆炸。",
        ),
    ] = ".*",
    markdown: Annotated[bool, typer.Option("--markdown", help="markdown 输出（默认）。")] = False,
    json_output: Annotated[bool, typer.Option("--json", help="结构化 JSON 输出。")] = False,
) -> None:
    """生成适合直接粘进 LLM prompt 的 schema 摘要（默认 markdown）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    try:
        pattern = re.compile(include_fields_pattern)
    except re.error as exc:
        raise MbcliError("invalid_args", f"invalid --include-fields-pattern: {exc}") from exc
    with state.build_client(config) as client:
        db_id = Resolver(client).db(effective_db_ref(db, config))
        metadata = client.get(f"/api/database/{db_id}/metadata")
    if not isinstance(metadata, dict):
        raise MbcliError("invalid_response", "database metadata response is not an object")
    all_tables = [item for item in metadata.get("tables") or [] if isinstance(item, dict)]
    selected = _context___select_tables(all_tables, table or [], max_tables)
    # FK columns resolve `fk_target_field_id` against the SAME response (no extra request)
    field_index = _context___field_index(all_tables)
    if json_output:
        typer.echo(render_json(_context___json_payload(metadata, selected, pattern, field_index)))
    else:
        typer.echo(_context___markdown(metadata, selected, pattern, field_index, len(all_tables)))


def _context___select_tables(
    tables: list[dict[str, Any]], refs: list[str], max_tables: int
) -> list[dict[str, Any]]:
    """Named tables must all resolve (not_found / ambiguous_ref, like the
    resolver); without --table, take the first N tables in name order
    (deterministic, DESIGN §4)."""
    if not refs:
        return sorted(tables, key=lambda t: str(t.get("name") or ""))[:max_tables]
    selected: list[dict[str, Any]] = []
    for ref in refs:
        if ref.isdigit():
            matches = [t for t in tables if str(t.get("id")) == ref]
        else:
            matches = [t for t in tables if t.get("name") == ref]
        if not matches:
            raise MbcliError(
                "not_found",
                f"table {ref!r} not found",
                detail={"kind": "table", "ref": ref},
            )
        if len(matches) > 1:
            raise MbcliError(
                "ambiguous_ref",
                f"table name {ref!r} matches {len(matches)} candidates; use the numeric id instead",
                detail={
                    "kind": "table",
                    "ref": ref,
                    "candidates": [{"id": t.get("id"), "name": t.get("name")} for t in matches],
                },
            )
        selected.append(matches[0])
    return selected


def _context___field_index(tables: list[dict[str, Any]]) -> dict[Any, tuple[str | None, str | None]]:
    """field id -> (table name, field name) across the whole metadata response."""
    index: dict[Any, tuple[str | None, str | None]] = {}
    for table in tables:
        table_name = table.get("name")
        for field in table.get("fields") or []:
            if isinstance(field, dict) and field.get("id") is not None:
                index[field["id"]] = (str(table_name), field.get("name"))
    return index


def _context___included_fields(table: dict[str, Any], pattern: re.Pattern[str]) -> list[dict[str, Any]]:
    fields = [f for f in table.get("fields") or [] if isinstance(f, dict)]
    return [f for f in fields if pattern.search(str(f.get("name") or ""))]


def _context___fk_label(field: dict[str, Any], field_index: dict[Any, tuple[str | None, str | None]]) -> str:
    fk_id = field.get("fk_target_field_id")
    if fk_id is None or fk_id not in field_index:
        return ""
    table_name, field_name = field_index[fk_id]
    return f"{table_name}.{field_name}"


def _context___markdown(
    metadata: dict[str, Any],
    tables: list[dict[str, Any]],
    pattern: re.Pattern[str],
    field_index: dict[Any, tuple[str | None, str | None]],
    total: int,
) -> str:
    """Markdown rendering, exact layout per DESIGN §6."""
    lines = [
        (
            f"# Database: {metadata.get('name')} ({metadata.get('engine')},"
            f" id={metadata.get('id')}) — {len(tables)} tables shown / {total} total"
        )
    ]
    for table in tables:
        rows = table.get("estimated_row_count")
        row_label = rows if rows is not None else "?"
        lines.append("")
        lines.append(f"## Table `{table.get('name')}` (id={table.get('id')}, ~{row_label} rows¹)")
        description = table.get("description")
        if description:
            lines.append(f"> {description}")
        lines.append("")
        lines.append("| column | type | semantic | pk | fk → | description |")
        lines.append("|---|---|---|---|---|---|")
        for field in _context___included_fields(table, pattern):
            lines.append(_context___field_row(field, field_index))
    lines.append("")
    lines.append(FOOTNOTE)
    return "\n".join(lines)


def _context___field_row(field: dict[str, Any], field_index: dict[Any, tuple[str | None, str | None]]) -> str:
    # markdown row per DESIGN §6: empty cells render as `| |` (single space),
    # non-empty cells as `| value |`
    cells = [
        field.get("name") or "",
        field.get("database_type") or "",
        # semantic column: semantic_type, falling back to base_type (§6 example)
        field.get("semantic_type") or field.get("base_type") or "",
        "PK" if field.get("database_is_pk") else "",
        _context___fk_label(field, field_index),
        field.get("description") or "",
    ]
    return "|" + "|".join(f" {cell} " if cell else " " for cell in cells) + "|"


def _context___json_payload(
    metadata: dict[str, Any],
    tables: list[dict[str, Any]],
    pattern: re.Pattern[str],
    field_index: dict[Any, tuple[str | None, str | None]],
) -> dict[str, Any]:
    """`--json` output: {"database":{…},"tables":[{…,"fields":[…]}]} (§5.1 shapes)."""
    out_tables: list[dict[str, Any]] = []
    for table in tables:
        record = TableInfo.from_api(table).to_dict()
        fields: list[dict[str, Any]] = []
        for field in _context___included_fields(table, pattern):
            info = FieldInfo.from_api(field)
            fk_id = field.get("fk_target_field_id")
            if fk_id in field_index:  # back-resolved within the same response
                target_table, target_field = field_index[fk_id]
                info.fk_target = FKTarget(table=target_table, field=target_field)
            fields.append(info.to_dict())
        record["field_count"] = len(fields)
        record["fields"] = fields
        out_tables.append(record)
    return {"database": DatabaseInfo.from_api(metadata).to_dict(), "tables": out_tables}

context = _ns(
    EPILOG=EPILOG,
    FOOTNOTE=FOOTNOTE,
    _field_index=_context___field_index,
    _field_row=_context___field_row,
    _fk_label=_context___fk_label,
    _included_fields=_context___included_fields,
    _json_payload=_context___json_payload,
    _markdown=_context___markdown,
    _select_tables=_context___select_tables,
    context=context,
)


#---------------------------------------------------------------------------
# mbcli.commands.freshness  (merged: src/mbcli/commands/freshness.py)
#---------------------------------------------------------------------------
EPILOG = (
    "示例:\n"
    "  mbcli freshness --db quant_data\n"
    "  mbcli freshness --db 15 --table app_mau --table stock_daily\n"
    "  mbcli freshness --db 15 --sample --max-tables 20   # 无指纹表显式采样"
)

# Time-column priority tiers (DESIGN §13.1): semantic type > temporal base type
# > name regex; ties break on the lowest database_position (fallback: UI
# position, per ADR #17). Lower tier number wins.
_freshness___TEMPORAL_SEMANTIC_TYPES = frozenset(
    {"type/CreationTimestamp", "type/UpdatedAt", "type/CreationTime"}
)
_freshness___TEMPORAL_BASE_TYPES = frozenset({"type/DateTime", "type/Date"})
_freshness___NAME_RE = re.compile(r"(^|_)(date|dt|day|month|year|time)$", re.IGNORECASE)

# Sub-fingerprint keys that may carry temporal bounds, most specific first.
_freshness___TEMPORAL_FINGERPRINT_KEYS = ("type/DateTime", "type/Date", "type/Time")


@dataclass
class FreshnessRow:
    """One output record; declaration order is the JSON key-order contract."""

    table: str | None
    table_id: int | None
    column: str | None
    min: Any
    max: Any
    source: str  # "fingerprint" | "sample" | "none"
    reason: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _freshness___field_position(field: dict[str, Any]) -> float:
    """database_position (physical column order), falling back to UI position."""
    for key in ("database_position", "position"):
        value = field.get(key)
        if value is not None:
            return float(value)
    return float("inf")


def _freshness___tier(field: dict[str, Any]) -> int:
    if field.get("semantic_type") in _freshness___TEMPORAL_SEMANTIC_TYPES:
        return 0
    if field.get("base_type") in _freshness___TEMPORAL_BASE_TYPES:
        return 1
    if _freshness___NAME_RE.search(str(field.get("name") or "")):
        return 2
    return 3


def _freshness___pick_time_column(fields: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Deterministic one-column-per-table pick (DESIGN §13.1); ties keep the
    first field in metadata order (stable sort)."""
    ranked = [(field, _freshness___tier(field)) for field in fields]
    ranked = [item for item in ranked if item[1] < 3]
    if not ranked:
        return None
    return min(ranked, key=lambda item: (item[1], _freshness___field_position(item[0])))[0]


def _freshness___first_present(mapping: dict[str, Any], keys: tuple[str, ...] | list[str]) -> Any:
    for key in keys:
        value = mapping.get(key)
        if value is not None:
            return value
    return None


def _freshness___fingerprint_bounds(field: dict[str, Any]) -> tuple[Any, Any]:
    """(min, max) from a field fingerprint, tolerant of every observed shape.

    Live v0.66 nests temporal bounds at type["type/DateTime"].{earliest,latest};
    older/hypothetical variants (flat {"min","max"} at the top, min/max inside
    the typed sub-dict, non-temporal Number min/max) are parsed too. Both bounds
    missing/unusable -> (None, None), i.e. "no fingerprint" for this column.
    """
    fingerprint = field.get("fingerprint")
    if not isinstance(fingerprint, dict):
        return None, None
    if "min" in fingerprint or "max" in fingerprint:  # flat variant
        return fingerprint.get("min"), fingerprint.get("max")
    typed = fingerprint.get("type")
    if not isinstance(typed, dict):
        return None, None
    for key in _freshness___TEMPORAL_FINGERPRINT_KEYS:
        sub = typed.get(key)
        if isinstance(sub, dict):
            low = _freshness___first_present(sub, ("earliest", "min"))
            high = _freshness___first_present(sub, ("latest", "max"))
            if low is not None or high is not None:
                return low, high
    # non-temporal typed fingerprints (e.g. type/Number) carry min/max directly
    for sub in typed.values():
        if isinstance(sub, dict) and (sub.get("min") is not None or sub.get("max") is not None):
            return sub.get("min"), sub.get("max")
    return None, None


def _freshness___quote_ident(identifier: str) -> str:
    """Always-backtick an identifier; embedded backticks are doubled."""
    return "`" + identifier.replace("`", "``") + "`"


def _freshness___sample_sql(table: dict[str, Any], field: dict[str, Any]) -> str:
    column = _freshness___quote_ident(str(field.get("name") or ""))
    table_ref = _freshness___quote_ident(str(table.get("name") or ""))
    schema = table.get("schema")
    if schema:
        table_ref = f"{_freshness___quote_ident(str(schema))}.{table_ref}"
    return f"SELECT MIN({column}), MAX({column}) FROM {table_ref}"


def _freshness___select_tables(
    tables: list[dict[str, Any]], refs: list[str], max_tables: int
) -> list[dict[str, Any]]:
    """Named tables must all resolve (not_found / ambiguous_ref); without
    --table, the first N tables in name order (deterministic, DESIGN §13.1)."""
    if not refs:
        return sorted(tables, key=lambda t: str(t.get("name") or ""))[:max_tables]
    selected: list[dict[str, Any]] = []
    for ref in refs:
        if ref.isdigit():
            matches = [t for t in tables if str(t.get("id")) == ref]
        else:
            matches = [t for t in tables if t.get("name") == ref]
        if not matches:
            raise MbcliError(
                "not_found",
                f"table {ref!r} not found",
                detail={"kind": "table", "ref": ref},
            )
        if len(matches) > 1:
            raise MbcliError(
                "ambiguous_ref",
                f"table name {ref!r} matches {len(matches)} candidates; use the numeric id instead",
                detail={
                    "kind": "table",
                    "ref": ref,
                    "candidates": [{"id": t.get("id"), "name": t.get("name")} for t in matches],
                },
            )
        selected.append(matches[0])
    return selected


def _freshness___sample_bounds(payload: Any) -> tuple[Any, Any]:
    """First row of a /api/dataset response -> (min, max); empty result -> nulls."""
    data = payload.get("data") if isinstance(payload, dict) else None
    rows = data.get("rows") if isinstance(data, dict) else None
    row = rows[0] if rows else []
    low = row[0] if len(row) > 0 else None
    high = row[1] if len(row) > 1 else None
    return low, high


def _freshness___freshness_row(client: Any, db_id: int, table: dict[str, Any], sample: bool) -> FreshnessRow:
    name = str(table.get("name"))
    columns = [f for f in table.get("fields") or [] if isinstance(f, dict)]
    column = _freshness___pick_time_column(columns)
    if column is None:
        return FreshnessRow(
            table=name,
            table_id=table.get("id"),
            column=None,
            min=None,
            max=None,
            source="none",
            reason="no time column",
        )
    column_name = column.get("name")
    low, high = _freshness___fingerprint_bounds(column)
    if low is not None or high is not None:
        return FreshnessRow(
            table=name,
            table_id=table.get("id"),
            column=column_name,
            min=low,
            max=high,
            source="fingerprint",
            reason=None,
        )
    if not sample:
        return FreshnessRow(
            table=name,
            table_id=table.get("id"),
            column=column_name,
            min=None,
            max=None,
            source="none",
            reason="no fingerprint (use --sample)",
        )
    payload = client.post_json(
        "/api/dataset",
        {
            "database": db_id,
            "type": "native",
            "native": {"query": _freshness___sample_sql(table, column), "template-tags": {}},
            "parameters": [],
        },
    )
    low, high = _freshness___sample_bounds(payload)
    return FreshnessRow(
        table=name,
        table_id=table.get("id"),
        column=column_name,
        min=low,
        max=high,
        source="sample",
        reason=None,
    )


def freshness(
    ctx: typer.Context,
    db: Annotated[
        str | None,
        typer.Option("--db", help="数据库 id 或名称（缺省回退：default_db / MB_DEFAULT_DB）。"),
    ] = None,
    table: Annotated[
        list[str] | None,
        typer.Option("--table", help="限定表（id 或名称，可重复）；缺省=全库前 N 张。"),
    ] = None,
    max_tables: Annotated[
        int,
        typer.Option("--max-tables", min=1, help="处理表数上限（默认 20，防查询风暴）。"),
    ] = 20,
    sample: Annotated[
        bool,
        typer.Option(
            "--sample", help="无指纹的表显式发 MIN/MAX 采样查询（默认只读指纹，零查询）。"
        ),
    ] = False,
    format: FormatOpt = Format.json,
    fields: FieldsOpt = None,
    out: OutOpt = None,
) -> None:
    """每表时间列的 min/max 数据新鲜度（优先读字段指纹，零查询；v0.2 wave 2 实现）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    db_ref = effective_db_ref(db, config)
    refs = table or []
    with state.build_client(config) as client:
        resolver = Resolver(client)
        db_id = resolver.db(db_ref)
        metadata = resolver._db_metadata(db_id)  # single metadata GET, cached
        entries = [t for t in metadata.get("tables") or [] if isinstance(t, dict)]
        selected = _freshness___select_tables(entries, refs, max_tables)
        truncated = not refs and len(entries) > len(selected)
        records = [_freshness___freshness_row(client, db_id, t, sample).to_dict() for t in selected]
    emit_records(
        records,
        fmt=format,
        fields=fields,
        out=out,
        truncated=truncated,
        no_color=state.no_color,
    )

freshness = _ns(
    EPILOG=EPILOG,
    FreshnessRow=FreshnessRow,
    _NAME_RE=_freshness___NAME_RE,
    _TEMPORAL_BASE_TYPES=_freshness___TEMPORAL_BASE_TYPES,
    _TEMPORAL_FINGERPRINT_KEYS=_freshness___TEMPORAL_FINGERPRINT_KEYS,
    _TEMPORAL_SEMANTIC_TYPES=_freshness___TEMPORAL_SEMANTIC_TYPES,
    _field_position=_freshness___field_position,
    _fingerprint_bounds=_freshness___fingerprint_bounds,
    _first_present=_freshness___first_present,
    _freshness_row=_freshness___freshness_row,
    _pick_time_column=_freshness___pick_time_column,
    _quote_ident=_freshness___quote_ident,
    _sample_bounds=_freshness___sample_bounds,
    _sample_sql=_freshness___sample_sql,
    _select_tables=_freshness___select_tables,
    _tier=_freshness___tier,
    freshness=freshness,
)


#---------------------------------------------------------------------------
# mbcli.commands.overview  (merged: src/mbcli/commands/overview.py)
#---------------------------------------------------------------------------
EPILOG = "示例:\n  mbcli overview\n  mbcli overview --top 20 --format markdown"

# §13.2: content distribution covers at most the first COLLECTION_CAP
# non-personal top-level collections; recents take one RECENT_PAGE_SIZE page
# per collection and keep the global --top newest after the merge.
COLLECTION_CAP = 50
RECENT_PAGE_SIZE = 100
RECENT_MODELS = ("card", "dashboard")
ROOT_COLLECTION: dict[str, Any] = {"id": "root", "name": "Our analytics"}

# Server-side signals that `include=tables` is not usable on this instance
# (param rejected / broken shape) -> per-db metadata fallback loop.
_overview___FALLBACK_CODES = frozenset({"invalid_request", "invalid_response", "not_found"})


# -- output dataclasses (local: frozen scope, models.py untouched) ----------------


@dataclass
class _overview___OverviewTotals:
    databases: int
    collections: int
    cards: int
    dashboards: int


@dataclass
class _overview___DatabaseTables:
    id: int | str
    name: str | None
    engine: str | None
    table_count: int


@dataclass
class _overview___CollectionCounters:
    collection: CollectionRef
    cards: int
    dashboards: int


@dataclass
class _overview___RecentItem:
    model: str | None
    id: int | str
    name: str | None
    collection: CollectionRef
    updated_at: str | None


@dataclass
class _overview___Overview:
    totals: _overview___OverviewTotals
    databases: list[_overview___DatabaseTables] = field(default_factory=list)
    collections: list[_overview___CollectionCounters] = field(default_factory=list)
    recent: list[_overview___RecentItem] = field(default_factory=list)
    slow: bool = False

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        if not self.slow:
            payload.pop("slow")  # fast path: the exact §13.2 shape, no marker
        return payload


# -- section builders --------------------------------------------------------------


def _overview___visible_table(table: dict[str, Any]) -> bool:
    """Same visibility rule as `mbcli tables` by default (no --include-hidden)."""
    return bool(table.get("active", True)) and not table.get("visibility_type")


def _overview___database_rows(client: MetabaseClient) -> tuple[list[_overview___DatabaseTables], bool]:
    """Databases x table_count. Fast path: one `GET /api/database?include=tables`
    (probe-verified on v0.66). Any db arriving without a tables array falls back
    to its own metadata call; the response marks the run as slow then."""
    try:
        payload = client.get("/api/database", params={"include": "tables"})
    except MbcliError as exc:
        if exc.code not in _overview___FALLBACK_CODES:
            raise  # auth/network/server errors: a metadata loop cannot help
        payload = client.get("/api/database")
    data = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(data, list):
        raise MbcliError("invalid_response", "/api/database response has no data array")
    rows: list[_overview___DatabaseTables] = []
    slow = False
    for item in data:
        if not isinstance(item, dict) or item.get("id") is None:
            continue
        tables = item.get("tables")
        if not isinstance(tables, list):
            metadata = client.get(f"/api/database/{item['id']}/metadata")
            tables = metadata.get("tables") if isinstance(metadata, dict) else None
            if not isinstance(tables, list):
                tables = []
            slow = True
        count = sum(1 for t in tables if isinstance(t, dict) and _overview___visible_table(t))
        rows.append(
            _overview___DatabaseTables(
                id=item["id"], name=item.get("name"), engine=item.get("engine"), table_count=count
            )
        )
    return rows, slow


def _overview___top_level_collections(client: MetabaseClient) -> list[dict[str, Any]]:
    """Non-personal top-level collections (parent_id null), root first, capped.

    The live /api/collection flat list does NOT include the root collection
    (probe-verified): synthesize "Our analytics" (id "root"); a server that
    does list it must not produce a duplicate."""
    payload = client.get("/api/collection")
    data = payload.get("data") if isinstance(payload, dict) else payload
    if not isinstance(data, list):
        raise MbcliError("invalid_response", "/api/collection response is not an array")
    entries = [dict(ROOT_COLLECTION)]
    for item in data:
        if not isinstance(item, dict) or item.get("id") is None:
            continue
        if item.get("is_personal") or item.get("parent_id") is not None:
            continue
        if item["id"] == "root":
            continue  # server already listed the root collection: no duplicate
        entries.append({"id": item["id"], "name": item.get("name")})
    return entries[:COLLECTION_CAP]


def _overview___model_total(client: MetabaseClient, collection_id: int | str, model: str) -> int:
    """`total` for one model via a 1-row probe page (2 quick calls per collection)."""
    payload = client.get(f"/api/collection/{collection_id}/items", {"models": [model], "limit": 1})
    total = payload.get("total") if isinstance(payload, dict) else None
    return total if isinstance(total, int) else 0


def _overview___recent_page(client: MetabaseClient, collection_id: int | str) -> list[dict[str, Any]]:
    """One merged card+dashboard items page (repeated models= params, §13.2)."""
    payload = client.get(
        f"/api/collection/{collection_id}/items",
        {"models": list(RECENT_MODELS), "limit": RECENT_PAGE_SIZE},
    )
    data = payload.get("data") if isinstance(payload, dict) else None
    return [item for item in (data or []) if isinstance(item, dict)]


def _overview___item_updated_at(item: dict[str, Any]) -> str | None:
    """Live items carry no updated_at: fall back to last-edit-info.timestamp."""
    updated = item.get("updated_at")
    if isinstance(updated, str) and updated:
        return updated
    last_edit = item.get("last-edit-info")
    if isinstance(last_edit, dict):
        timestamp = last_edit.get("timestamp")
        if isinstance(timestamp, str):
            return timestamp
    return None


# -- output ------------------------------------------------------------------------


def _overview___recent_collection_cell(ref: dict[str, Any]) -> str:
    return str(ref["name"] if ref.get("name") is not None else ref["id"])


def _overview___render_sections(record: dict[str, Any], *, fmt: Format, no_color: bool) -> str:
    """table/markdown: databases and collections as record tables, recent as a
    list; totals (and the slow-path note, when set) lead as plain header lines."""

    def render(header: list[str], rows: list[list[Any]]) -> str:
        if fmt is Format.table:
            return render_table(header, rows, no_color=no_color)
        return render_markdown(header, rows)

    totals = record["totals"]
    parts = [
        (
            "Totals: "
            f"{totals['databases']} databases, {totals['collections']} collections,"
            f" {totals['cards']} cards, {totals['dashboards']} dashboards"
        )
    ]
    if record.get("slow"):
        parts.append("(slow path: include=tables unavailable, per-database metadata fallback)")
    parts.append("Databases")
    parts.append(
        render(
            ["id", "name", "engine", "table_count"],
            [[d["id"], d["name"], d["engine"], d["table_count"]] for d in record["databases"]],
        )
    )
    parts.append("Collections")
    parts.append(
        render(
            ["id", "name", "cards", "dashboards"],
            [
                [c["collection"]["id"], c["collection"]["name"], c["cards"], c["dashboards"]]
                for c in record["collections"]
            ],
        )
    )
    parts.append("Recent")
    parts.append(
        render(
            ["model", "id", "name", "collection", "updated_at"],
            [
                [
                    r["model"],
                    r["id"],
                    r["name"],
                    _overview___recent_collection_cell(r["collection"]),
                    r["updated_at"],
                ]
                for r in record["recent"]
            ],
        )
    )
    return "\n".join(parts) + "\n"


def _overview___finalize(text: str, out: str | None) -> None:
    """stdout, or write to --out and print the summary object (§3.6 semantics)."""
    if out is None:
        if not text.endswith("\n"):
            text += "\n"
        sys.stdout.write(text)
        return
    Path(out).expanduser().write_text(text, encoding="utf-8")
    sys.stdout.write(
        json.dumps({"out": out, "rows": 1, "truncated": False}, ensure_ascii=False) + "\n"
    )


def _overview___emit(record: dict[str, Any], *, fmt: Format, out: str | None, no_color: bool) -> None:
    if fmt is Format.json:
        text = render_json(record)
    elif fmt in (Format.table, Format.markdown):
        text = _overview___render_sections(record, fmt=fmt, no_color=no_color)
    else:
        raise MbcliError(
            "invalid_args",
            f"format '{fmt.value}' is not supported for overview (single object with"
            " two record arrays): use json, table or markdown",
        )
    _overview___finalize(text, out)


# -- command body -------------------------------------------------------------------


def overview(
    ctx: typer.Context,
    top: Annotated[int, typer.Option("--top", min=1, help="最近更新资产条数（默认 10）。")] = 10,
    format: FormatOpt = Format.json,
    out: OutOpt = None,
) -> None:
    """实例总览：库×表数、集合内容分布、最近更新（v0.2 wave 2 实现）。"""
    state = state_from_ctx(ctx)
    config = state.load_config()
    with state.build_client(config) as client:
        databases, slow = _overview___database_rows(client)
        collections: list[_overview___CollectionCounters] = []
        recent: list[_overview___RecentItem] = []
        for entry in _overview___top_level_collections(client):
            cards = _overview___model_total(client, entry["id"], "card")
            dashboards = _overview___model_total(client, entry["id"], "dashboard")
            collections.append(
                _overview___CollectionCounters(
                    collection=CollectionRef(id=entry["id"], name=entry["name"]),
                    cards=cards,
                    dashboards=dashboards,
                )
            )
            if cards + dashboards == 0:
                continue  # empty collection: nothing to merge into recents
            for item in _overview___recent_page(client, entry["id"]):
                if item.get("model") not in RECENT_MODELS:
                    continue
                recent.append(
                    _overview___RecentItem(
                        model=item.get("model"),
                        id=item.get("id"),
                        name=item.get("name"),
                        collection=CollectionRef(id=entry["id"], name=entry["name"]),
                        updated_at=_overview___item_updated_at(item),
                    )
                )
    recent.sort(key=lambda item: (item.updated_at is not None, item.updated_at or ""), reverse=True)
    record = _overview___Overview(
        totals=_overview___OverviewTotals(
            databases=len(databases),
            collections=len(collections),
            cards=sum(entry.cards for entry in collections),
            dashboards=sum(entry.dashboards for entry in collections),
        ),
        databases=databases,
        collections=collections,
        recent=recent[:top],
        slow=slow,
    ).to_dict()
    _overview___emit(record, fmt=format, out=out, no_color=state.no_color)

overview = _ns(
    COLLECTION_CAP=COLLECTION_CAP,
    EPILOG=EPILOG,
    RECENT_MODELS=RECENT_MODELS,
    RECENT_PAGE_SIZE=RECENT_PAGE_SIZE,
    ROOT_COLLECTION=ROOT_COLLECTION,
    _CollectionCounters=_overview___CollectionCounters,
    _DatabaseTables=_overview___DatabaseTables,
    _FALLBACK_CODES=_overview___FALLBACK_CODES,
    _Overview=_overview___Overview,
    _OverviewTotals=_overview___OverviewTotals,
    _RecentItem=_overview___RecentItem,
    _database_rows=_overview___database_rows,
    _emit=_overview___emit,
    _finalize=_overview___finalize,
    _item_updated_at=_overview___item_updated_at,
    _model_total=_overview___model_total,
    _recent_collection_cell=_overview___recent_collection_cell,
    _recent_page=_overview___recent_page,
    _render_sections=_overview___render_sections,
    _top_level_collections=_overview___top_level_collections,
    _visible_table=_overview___visible_table,
    overview=overview,
)


#---------------------------------------------------------------------------
# mbcli.commands.batch  (merged: src/mbcli/commands/batch.py)
#---------------------------------------------------------------------------
EPILOG = (
    "示例:\n  printf 'tables --db 15 --match fut\\n# 注释行\\nfields --table 3258\\n' | mbcli batch"
)


def _batch___error_object(error: MbcliError) -> dict[str, Any]:
    """Reuse the §3.3 stderr contract to build a line's `error` value."""
    return json.loads(error.to_stderr_json())["error"]


def _batch___stderr_error_object(stderr_text: str) -> dict[str, Any] | None:
    """Last parseable `{"error":{…}}` line from a command's captured stderr
    (-v request logs are not JSON and are skipped); None when there is none."""
    for line in reversed(stderr_text.strip().splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except ValueError:
            continue
        if isinstance(payload, dict) and isinstance(payload.get("error"), dict):
            return payload["error"]
        return None
    return None


def _batch___result_value(stdout_text: str) -> Any:
    """The inner command's stdout: parsed JSON when it parses, else the raw
    string (e.g. `--format csv` / `--format table`); empty output -> None."""
    if not stdout_text.strip():
        return None
    try:
        return json.loads(stdout_text)
    except ValueError:
        return stdout_text


def _batch___execute(argv: list[str]) -> dict[str, Any]:
    """Run one subcommand argv IN-PROCESS via mbcli.cli:main — the real entry
    point, so the MbcliError/TyperException -> stderr-JSON / exit-code contract
    is identical to a standalone invocation. A line failure never propagates."""
    mbcli_main = main  # merged intra alias

    out_buf, err_buf = io.StringIO(), io.StringIO()
    exit_code = 0
    try:
        with contextlib.redirect_stdout(out_buf), contextlib.redirect_stderr(err_buf):
            mbcli_main(list(argv))
    except SystemExit as exc:
        code = exc.code
        if code is None:
            exit_code = 0
        elif isinstance(code, int):  # bool is an int subclass; int() anyway
            exit_code = int(code)
        else:
            exit_code = 1  # sys.exit("message") style: treat as failure
    except Exception as exc:  # noqa: BLE001 — line isolation is the contract
        exit_code = 1
        internal = MbcliError("invalid_response", f"unexpected failure: {exc}")
        err_buf.write(internal.to_stderr_json() + "\n")
    return {
        "exit": exit_code,
        "error": _batch___stderr_error_object(err_buf.getvalue()),
        "result": _batch___result_value(out_buf.getvalue()),
    }


def batch(ctx: typer.Context) -> None:
    """从 stdin 逐行读取子命令 argv，单进程批量执行（NDJSON 输出；v0.2 wave 3 实现）。"""
    failures = 0
    index = 0
    for raw in sys.stdin.read().splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        index += 1
        try:
            argv = shlex.split(line)
        except ValueError as exc:
            argv = [line]
            outcome = {
                "exit": 2,
                "error": _batch___error_object(
                    MbcliError("invalid_args", f"shlex parse failed: {exc}", detail={"line": line})
                ),
                "result": None,
            }
        else:
            if argv and argv[0] == "batch":
                outcome = {
                    "exit": 2,
                    "error": _batch___error_object(
                        MbcliError(
                            "invalid_args",
                            "nested 'batch' is not allowed inside batch lines",
                            detail={"line": line},
                        )
                    ),
                    "result": None,
                }
            else:
                outcome = _batch___execute(argv)
        entry: dict[str, Any] = {"index": index, "argv": argv}
        entry.update(outcome)
        sys.stdout.write(json.dumps(entry, ensure_ascii=False) + "\n")
        sys.stdout.flush()
        if entry["exit"] != 0:
            failures += 1
    if failures:
        raise typer.Exit(1)

batch = _ns(
    EPILOG=EPILOG,
    _error_object=_batch___error_object,
    _execute=_batch___execute,
    _result_value=_batch___result_value,
    _stderr_error_object=_batch___stderr_error_object,
    batch=batch,
)


#---------------------------------------------------------------------------
# mbcli.cli  (merged: src/mbcli/cli.py)
#---------------------------------------------------------------------------
app = typer.Typer(
    name="mbcli",
    help="面向 Agent 的 Metabase 命令行客户端：stdout 只输出数据（默认 JSON），诊断与错误走 stderr。",
    epilog=(
        "选项文法：连接/诊断选项（--url/--api-key/--username/--password/--timeout/--no-color/-v）"
        "必须放在子命令之前；数据塑形选项（--format/--fields/--max-rows/--out 及各命令专属选项）"
        "放在子命令之后。\n"
        '退出码：0 成功；1 API/执行错误（stderr 单行 JSON，形如 {"error":{"code":"…"}}）；'
        "2 用法错误（改参数即可修复）。\n"
        "完整使用文档见 USAGE.md。"
    ),
    add_completion=False,
    pretty_exceptions_enable=False,
    pretty_exceptions_show_locals=False,
)


@app.callback(invoke_without_command=True)
def root(
    ctx: typer.Context,
    url: Annotated[
        str | None, typer.Option("--url", help="Metabase 实例根地址（env: MB_URL）。")
    ] = None,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", help="Metabase API Key，优先于账密登录（env: MB_API_KEY）。"),
    ] = None,
    username: Annotated[
        str | None, typer.Option("--username", help="登录用户名（env: MB_USERNAME）。")
    ] = None,
    password: Annotated[
        str | None,
        typer.Option(
            "--password", help="登录密码；仅限交互调试，推荐 env 传入（env: MB_PASSWORD）。"
        ),
    ] = None,
    timeout: Annotated[
        int | None,
        typer.Option("--timeout", min=1, help="单请求 read 超时秒数，默认 60（env: MB_TIMEOUT）。"),
    ] = None,
    no_color: Annotated[bool, typer.Option("--no-color", help="关闭彩色输出。")] = False,
    verbose: Annotated[
        bool,
        typer.Option("-v", "--verbose", help="请求日志输出到 stderr（凭据已脱敏）。"),
    ] = False,
) -> None:
    """连接与诊断选项必须放在子命令之前（数据塑形选项放在子命令之后）。"""
    ctx.obj = CliState(
        url=url,
        api_key=api_key,
        username=username,
        password=password,
        timeout=timeout,
        verbose=verbose,
        no_color=no_color,
    )
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)


# Command modules are imported after the callback definition: cli.py owns
# registration, commands only depend on core modules (no import cycle).

app.command("health", epilog=health.EPILOG)(health.health)
app.command("whoami", epilog=whoami.EPILOG)(whoami.whoami)
app.command("connect", epilog=connect.EPILOG)(connect.connect)
app.command("disconnect", epilog=connect.DISCONNECT_EPILOG)(connect.disconnect)
app.add_typer(databases.app, name="databases", help="浏览数据库。")
app.command("schemas", epilog=schemas.EPILOG)(schemas.schemas)
app.command("tables", epilog=tables.EPILOG)(tables.tables)
app.command("fields", epilog=fields.EPILOG)(fields.fields)
app.command("query", epilog=query.EPILOG)(query.query)
app.add_typer(cards.app, name="cards", help="执行或查看已保存的问题（卡片）。")
app.add_typer(collections.app, name="collections", help="浏览集合及其内容。")
app.add_typer(dashboards.app, name="dashboards", help="查看仪表盘。")
app.command("search", epilog=search.EPILOG)(search.search)
app.command("context", epilog=context.EPILOG)(context.context)


# -- v0.2 (DESIGN §13): 命令体迁移至各自模块（wave 1 注册的最终签名不变）--------
app.command("freshness", epilog=freshness.EPILOG)(freshness.freshness)
app.command("overview", epilog=overview.EPILOG)(overview.overview)
app.command("batch", epilog=batch.EPILOG)(batch.batch)


def main(argv: list[str] | None = None) -> None:
    """Console-script entry point. Translates exceptions into the exit contract."""
    try:
        code = app(args=argv, standalone_mode=False)
        sys.exit(int(code or 0))
    except typer.TyperException as exc:
        # Usage/parameter errors from the CLI layer -> invalid_args (exit 2).
        if type(exc).__name__ == "NoArgsIsHelpError":  # bare `mbcli databases` etc.
            typer.echo(str(exc.format_message()))
            error = MbcliError("invalid_args", "no subcommand given; run with --help")
        else:
            message = " ".join(str(exc.format_message()).split())
            error = MbcliError("invalid_args", message, detail={"cli_error": message})
        error.emit()
        sys.exit(error.exit_code)
    except MbcliError as exc:
        exc.emit()
        sys.exit(exc.exit_code)
    except (typer.Abort, KeyboardInterrupt):
        sys.stderr.write('{"error":{"code":"aborted","message":"aborted by user","detail":{}}}\n')
        sys.exit(130)

cli = _ns(
    app=app,
    main=main,
    root=root,
)


if __name__ == "__main__":
    main()
